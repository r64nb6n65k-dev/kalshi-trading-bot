"""Market data and trade recording.

Files written under the data directory (one set per UTC day):

* ``raw/YYYY-MM-DD.jsonl.gz``    every WebSocket message plus market metadata
                                 and settlement results; ``scalper-replay``
                                 re-runs the strategy over these.
* ``ticks/YYYY-MM-DD.csv.gz``    one row per market per second: prices, depth,
                                 momentum, taker flow, liquidity tier.
* ``scalper_trades.csv``         every closed scalp with entry features.
* ``scalper_events.csv``         signals, entries, missed fills, order errors.
* ``market_results.csv``         settlement result of every market seen.
"""

from __future__ import annotations

import csv
import gzip
import io
import json
import os
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def default_data_dir() -> Path:
    volume = os.getenv("RAILWAY_VOLUME_MOUNT_PATH")
    base = Path(volume) if volume else Path("data")
    return Path(os.getenv("SCALPER_DATA_DIR", str(base / "scalper")))


def _day(ts: float) -> str:
    return datetime.fromtimestamp(ts, UTC).strftime("%Y-%m-%d")


class _DailyGzip:
    def __init__(self, folder: Path, suffix: str) -> None:
        self.folder = folder
        self.suffix = suffix
        self.day = ""
        self.handle: gzip.GzipFile | None = None
        self.text: io.TextIOWrapper | None = None

    def get(self, ts: float) -> tuple[io.TextIOWrapper, bool]:
        day = _day(ts)
        new_file = False
        if day != self.day or self.text is None:
            self.close()
            self.folder.mkdir(parents=True, exist_ok=True)
            path = self.folder / f"{day}{self.suffix}"
            new_file = not path.exists()
            self.handle = gzip.open(path, "ab")  # type: ignore[assignment]
            self.text = io.TextIOWrapper(self.handle, encoding="utf-8", newline="")  # type: ignore[arg-type]
            self.day = day
        return self.text, new_file

    def flush(self) -> None:
        if self.text is not None:
            self.text.flush()
            assert self.handle is not None
            self.handle.flush()

    def close(self) -> None:
        if self.text is not None:
            try:
                self.text.close()
            except Exception:
                pass
        self.text = None
        self.handle = None


class Recorder:
    TICK_FIELDS = [
        "ts", "series", "ticker", "seconds_left", "yes_bid", "yes_ask", "spread",
        "yes_bid_size", "yes_ask_size", "yes_depth", "no_depth", "move_10s",
        "move_30s", "move_60s", "up_cents_15s", "down_cents_15s", "yes_taker_30s",
        "no_taker_30s", "tier", "trade_rate", "profile_spread", "profile_depth",
        "typical_move", "position", "reason",
    ]
    TRADE_FIELDS = [
        "mode", "series", "ticker", "tier", "side", "count", "entry_price",
        "exit_price", "entry_fee", "exit_fee", "gross_cents", "net_cents", "reason",
        "entry_ts", "exit_ts", "hold_seconds", "best_bid", "worst_bid", "move_30s",
        "move_10s", "flow_ratio", "imbalance", "spread", "seconds_left_at_entry",
        "trade_rate", "typical_move", "daily_net_cents",
    ]

    def __init__(self, data_dir: Path | str | None = None, record_raw: bool = True) -> None:
        self.dir = Path(data_dir) if data_dir else default_data_dir()
        self.dir.mkdir(parents=True, exist_ok=True)
        self.record_raw = record_raw
        self._raw = _DailyGzip(self.dir / "raw", ".jsonl.gz")
        self._ticks = _DailyGzip(self.dir / "ticks", ".csv.gz")
        self._tick_writer: csv.DictWriter[str] | None = None
        self._tick_day = ""
        self._last_flush = time.monotonic()

    # -------------------------------------------------------------- raw
    def _raw_line(self, record: dict[str, Any], ts: float) -> None:
        if not self.record_raw:
            return
        handle, _ = self._raw.get(ts)
        handle.write(json.dumps(record, separators=(",", ":")) + "\n")

    def message(self, message: dict[str, Any], ts: float) -> None:
        self._raw_line({"rt": round(ts, 3), "m": message}, ts)

    def market(self, info: dict[str, Any], ts: float) -> None:
        self._raw_line({"rt": round(ts, 3), "market": info}, ts)

    def reset(self, ts: float) -> None:
        """Mark a reconnect so replay drops the stale book like the live bot did."""
        self._raw_line({"rt": round(ts, 3), "reset": 1}, ts)

    def result(self, ticker: str, series: str, result: str, ts: float) -> None:
        self._raw_line({"rt": round(ts, 3), "result": {"ticker": ticker, "result": result}}, ts)
        self._append_csv(
            "market_results.csv",
            ["recorded_at", "series", "ticker", "result"],
            {"recorded_at": datetime.fromtimestamp(ts, UTC).isoformat(), "series": series,
             "ticker": ticker, "result": result},
        )

    # ------------------------------------------------------------ ticks
    def ticks(self, rows: list[dict[str, Any]], ts: float) -> None:
        if not rows:
            return
        handle, new_file = self._ticks.get(ts)
        if self._tick_writer is None or self._tick_day != self._ticks.day:
            self._tick_writer = csv.DictWriter(handle, fieldnames=self.TICK_FIELDS, extrasaction="ignore")
            self._tick_day = self._ticks.day
            if new_file:
                self._tick_writer.writeheader()
        self._tick_writer.writerows(rows)

    # ----------------------------------------------------------- events
    def trade(self, record: dict[str, Any]) -> None:
        self._append_csv("scalper_trades.csv", self.TRADE_FIELDS, record)

    def event(self, kind: str, data: dict[str, Any], ts: float) -> None:
        self._append_csv(
            "scalper_events.csv",
            ["ts", "event", "ticker", "data"],
            {"ts": datetime.fromtimestamp(ts, UTC).isoformat(), "event": kind,
             "ticker": data.get("ticker", ""), "data": json.dumps(data, default=str)},
        )

    def _append_csv(self, name: str, fields: list[str], row: dict[str, Any]) -> None:
        path = self.dir / name
        new_file = not path.exists() or path.stat().st_size == 0
        with path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            if new_file:
                writer.writeheader()
            writer.writerow(row)

    # ------------------------------------------------------------ admin
    def maybe_flush(self, every: float = 2.0) -> None:
        now = time.monotonic()
        if now - self._last_flush >= every:
            self.flush()
            self._last_flush = now

    def flush(self) -> None:
        self._raw.flush()
        self._ticks.flush()

    def close(self) -> None:
        self._raw.close()
        self._ticks.close()


def read_raw(path: Path) -> list[dict[str, Any]]:
    """Read a raw day file, tolerating a truncated final gzip member."""
    records: list[dict[str, Any]] = []
    try:
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except (EOFError, gzip.BadGzipFile, OSError):
        pass
    return records
