"""Per-market price history and per-series liquidity profiles."""

from __future__ import annotations

import statistics
from collections import deque
from dataclasses import asdict, dataclass, field, fields
from decimal import Decimal
from typing import Any

from kalshi_bot.momentum_scalper.config import HIGH, MEDIUM, THIN, WARMUP, ScalperConfig
from kalshi_bot.scalping.book import BinaryOrderBook, contracts, dollars_to_cents


@dataclass(slots=True)
class MarketInfo:
    ticker: str
    series: str
    open_ts: float
    close_ts: float
    exchange_index: int | None = None
    floor_strike: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MarketInfo:
        return cls(**{f.name: data.get(f.name) for f in fields(cls)})


@dataclass(slots=True)
class TradePrint:
    ts: float
    yes_price: int
    count: int
    taker_side: str  # "yes" = buyer lifted YES ask, "no" = buyer lifted NO ask


def _price_cents(raw: Any) -> int:
    value = Decimal(str(raw))
    return dollars_to_cents(value) if value <= 1 else int(value)


def parse_trade(payload: dict[str, Any], received_ts: float) -> TradePrint | None:
    yes_raw = payload.get("yes_price_dollars")
    if yes_raw is None:
        yes_raw = payload.get("yes_price")
    if yes_raw is None:
        no_raw = payload.get("no_price_dollars", payload.get("no_price"))
        if no_raw is None:
            return None
        yes_price = 100 - _price_cents(no_raw)
    else:
        yes_price = _price_cents(yes_raw)
    count_raw = payload.get("count_fp", payload.get("count", 0))
    count = contracts(count_raw)
    side = str(payload.get("taker_side", "")).lower()
    if count <= 0 or side not in {"yes", "no"}:
        return None
    return TradePrint(received_ts, yes_price, count, side)


def side_depth(book: BinaryOrderBook, outcome: str, band: int) -> int:
    levels = book.yes if outcome == "yes" else book.no
    best = book.bid(outcome)
    if best is None:
        return 0
    return sum(size for price, size in levels.items() if price > best - band)


def ask_levels(book: BinaryOrderBook, outcome: str) -> list[tuple[int, int]]:
    """Ascending (price, size) levels a buyer of ``outcome`` can lift."""
    opposite = book.no if outcome == "yes" else book.yes
    return sorted((100 - price, size) for price, size in opposite.items())


def bid_levels(book: BinaryOrderBook, outcome: str) -> list[tuple[int, int]]:
    """Descending (price, size) levels a seller of ``outcome`` can hit."""
    levels = book.yes if outcome == "yes" else book.no
    return sorted(levels.items(), reverse=True)


@dataclass(slots=True)
class TickerState:
    info: MarketInfo
    book: BinaryOrderBook
    # (ts, mid) sampled on every engine step while the book is two-sided.
    mids: deque[tuple[float, float]] = field(default_factory=lambda: deque(maxlen=2000))
    trades: deque[TradePrint] = field(default_factory=lambda: deque(maxlen=5000))
    first_seen: float = 0.0

    @classmethod
    def create(cls, info: MarketInfo, now: float) -> TickerState:
        return cls(info=info, book=BinaryOrderBook(info.ticker), first_seen=now)

    def mid(self) -> float | None:
        bid, ask = self.book.yes_bid, self.book.yes_ask
        if bid is None or ask is None:
            return None
        return (bid + ask) / 2.0

    def sample(self, now: float) -> None:
        mid = self.mid()
        if mid is not None:
            self.mids.append((now, mid))
        horizon = now - 120.0
        while self.trades and self.trades[0].ts < horizon:
            self.trades.popleft()

    def mid_at(self, ts: float) -> float | None:
        """Latest sampled mid at or before ``ts``."""
        found = None
        for sample_ts, mid in reversed(self.mids):
            if sample_ts <= ts:
                found = mid
                break
        return found

    def history_covers(self, seconds: float, now: float) -> bool:
        return bool(self.mids) and self.mids[0][0] <= now - seconds

    def flow(self, window: float, now: float) -> tuple[int, int]:
        yes = no = 0
        start = now - window
        for trade in reversed(self.trades):
            if trade.ts < start:
                break
            if trade.taker_side == "yes":
                yes += trade.count
            else:
                no += trade.count
        return yes, no

    def seconds_left(self, now: float) -> float:
        return self.info.close_ts - now

    def age(self, now: float) -> float:
        return now - max(self.info.open_ts, self.first_seen)


@dataclass(slots=True)
class ProfileStats:
    tier: str
    trade_rate: float  # contracts / minute
    spread: float | None
    depth: float | None
    typical_move: float  # median |30s mid change|, cents
    observed_seconds: float


class SeriesProfile:
    """Rolling liquidity and volatility profile for one series (e.g. KXBTC15M).

    It spans consecutive 15-minute markets, so a fresh market inherits what
    the series normally looks like instead of starting blind.
    """

    _SAMPLE_EVERY = 5.0

    def __init__(self, series: str, now: float) -> None:
        self.series = series
        self.started = now
        self._samples: deque[tuple[float, str, float, int, int]] = deque()
        self._trades: deque[tuple[float, int]] = deque()
        self._last_sample = 0.0
        self._stats: ProfileStats | None = None
        self._stats_ts = 0.0

    def on_trade(self, trade: TradePrint) -> None:
        self._trades.append((trade.ts, trade.count))

    def sample(self, state: TickerState, now: float, band: int) -> None:
        if now - self._last_sample < self._SAMPLE_EVERY:
            return
        mid = state.mid()
        spread = state.book.spread
        if mid is None or spread is None:
            return
        depth = side_depth(state.book, "yes", band) + side_depth(state.book, "no", band)
        self._samples.append((now, state.info.ticker, mid, spread, depth))
        self._last_sample = now

    def _trim(self, now: float, window: float) -> None:
        horizon = now - window
        while self._samples and self._samples[0][0] < horizon:
            self._samples.popleft()
        while self._trades and self._trades[0][0] < horizon:
            self._trades.popleft()

    def stats(self, now: float, cfg: ScalperConfig) -> ProfileStats:
        if self._stats is not None and now - self._stats_ts < 5.0:
            return self._stats
        self._trim(now, cfg.profile_window_seconds)
        observed = now - self.started
        span = max(1.0, min(observed, cfg.profile_window_seconds))
        trade_rate = sum(count for _, count in self._trades) * 60.0 / span

        spreads = [s[3] for s in self._samples]
        depths = [s[4] for s in self._samples]
        spread = statistics.median(spreads) if spreads else None
        depth = statistics.median(depths) if depths else None

        moves: list[float] = []
        samples = list(self._samples)
        for i, (ts, ticker, mid, _, _) in enumerate(samples):
            for j in range(i - 1, -1, -1):
                prev_ts, prev_ticker, prev_mid, _, _ = samples[j]
                if ts - prev_ts >= 30.0:
                    if prev_ticker == ticker and ts - prev_ts <= 40.0:
                        moves.append(abs(mid - prev_mid))
                    break
        typical = max(1.0, statistics.median(moves)) if moves else 1.0

        if observed < cfg.profile_warmup_seconds or spread is None or depth is None:
            tier = WARMUP
        elif (
            trade_rate >= cfg.high_min_trade_rate
            and depth >= cfg.high_min_depth
            and spread <= cfg.high_max_spread
        ):
            tier = HIGH
        elif (
            trade_rate >= cfg.medium_min_trade_rate
            and depth >= cfg.medium_min_depth
            and spread <= cfg.medium_max_spread
        ):
            tier = MEDIUM
        else:
            tier = THIN

        self._stats = ProfileStats(tier, trade_rate, spread, depth, typical, observed)
        self._stats_ts = now
        return self._stats
