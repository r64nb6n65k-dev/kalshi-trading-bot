"""Tests for the Kalshi momentum scalper (pure Python, no network)."""

from __future__ import annotations

import asyncio
import gzip
import json
from pathlib import Path

from kalshi_bot.momentum_scalper.brokers import PaperBroker, simulate_ioc
from kalshi_bot.momentum_scalper.config import HIGH, THIN, ScalperConfig
from kalshi_bot.momentum_scalper.core import Fill, Intent, ScalperCore
from kalshi_bot.momentum_scalper.fees import taker_fee_cents
from kalshi_bot.momentum_scalper.market_state import MarketInfo
from kalshi_bot.momentum_scalper.recorder import Recorder, read_raw
from kalshi_bot.momentum_scalper.replay import replay_files, replay_records
from kalshi_bot.momentum_scalper.report import hold_rate_at, liquidity_summary, trade_summary
from kalshi_bot.scalping.book import BinaryOrderBook

from tests.unit.scalper_sim import T0, build_stream, quiet_walk, snapshot

TICKER = "KXBTC15M-TEST-00"
SERIES = "KXBTC15M"


def surge_volume(start: float, end: float, heavy: int = 8):
    return lambda t: heavy if start <= t < end else 3


def breakout_up(t: float, walk=quiet_walk()) -> float:
    if t < 300:
        return walk(t)
    if t < 312:
        return 50 + (t - 300)
    if t < 360:
        return 62 + (t - 312) * 0.4
    return 81.2


def run(records, **overrides) -> ScalperCore:
    cfg = ScalperConfig()
    for key, value in overrides.items():
        setattr(cfg, key, value)
    return replay_records(records, cfg)


# --------------------------------------------------------------- fees
def test_fee_matches_kalshi_trade_log() -> None:
    # Values taken from the adaptive bot's recorded trades.
    assert taker_fee_cents(2, 75) == 3
    assert taker_fee_cents(2, 26) == 3
    assert taker_fee_cents(2, 45) == 4
    assert taker_fee_cents(1, 23) == 2
    assert taker_fee_cents(2, 61) == 4
    assert taker_fee_cents(0, 50) == 0


# ------------------------------------------------------------- fills
def _book() -> BinaryOrderBook:
    book = BinaryOrderBook(TICKER)
    book.apply({
        "type": "orderbook_snapshot",
        "seq": 1,
        "msg": {
            "market_ticker": TICKER,
            "yes_dollars_fp": [["0.40", "10.00"], ["0.39", "50.00"]],
            "no_dollars_fp": [["0.58", "3.00"], ["0.57", "4.00"], ["0.50", "100.00"]],
        },
    })
    return book


def test_ioc_buy_walks_asks_up_to_limit_only() -> None:
    book = _book()  # YES asks: 42 x3, 43 x4, 50 x100
    fill = simulate_ioc(Intent(1, TICKER, "buy", "yes", 10, 43, "ENTRY"), book)
    assert fill.count == 7
    assert abs(fill.avg_price - (42 * 3 + 43 * 4) / 7) < 1e-9
    assert fill.fee_cents == taker_fee_cents(7, 43) or fill.fee_cents > 0


def test_ioc_sell_hits_bids_down_to_limit() -> None:
    book = _book()  # YES bids: 40 x10, 39 x50
    fill = simulate_ioc(Intent(2, TICKER, "sell", "yes", 15, 40, "TAKE_PROFIT"), book)
    assert fill.count == 10 and fill.avg_price == 40
    no_fill = simulate_ioc(Intent(3, TICKER, "sell", "yes", 5, 41, "TAKE_PROFIT"), book)
    assert no_fill.count == 0


def test_no_side_prices_are_complements() -> None:
    book = _book()  # NO asks come from YES bids: 60 x10, 61 x50
    fill = simulate_ioc(Intent(4, TICKER, "buy", "no", 12, 61, "ENTRY"), book)
    assert fill.count == 12
    assert abs(fill.avg_price - (60 * 10 + 61 * 2) / 12) < 1e-9


# ---------------------------------------------------------- scenarios
def test_breakout_up_buys_yes_and_takes_ten_cents() -> None:
    records = build_stream(
        TICKER, SERIES, 420, breakout_up,
        trades_at=surge_volume(290, 345),
        yes_share_at=lambda t: 0.95 if 290 <= t < 345 else 0.5,
        tilt_at=lambda t: 0.3 if 290 <= t < 345 else 0.0,
    )
    core = run(records)
    assert core.closed_trades, core.last_reason
    trade = core.closed_trades[0]
    assert trade["side"] == "yes"
    assert trade["tier"] == HIGH
    assert trade["reason"] == "TAKE_PROFIT"
    assert trade["exit_price"] - trade["entry_price"] >= 10
    expected_fees = taker_fee_cents(5, round(trade["entry_price"])) + taker_fee_cents(5, round(trade["exit_price"]))
    assert trade["entry_fee"] + trade["exit_fee"] == expected_fees
    assert trade["net_cents"] == trade["gross_cents"] - expected_fees > 0


def test_breakdown_buys_no_side() -> None:
    walk = quiet_walk()

    def down(t: float) -> float:
        if t < 300:
            return walk(t)
        if t < 312:
            return 50 - (t - 300)
        if t < 360:
            return 38 - (t - 312) * 0.4
        return 18.8

    records = build_stream(
        TICKER, SERIES, 420, down,
        trades_at=surge_volume(290, 345),
        yes_share_at=lambda t: 0.05 if 290 <= t < 345 else 0.5,
        tilt_at=lambda t: -0.3 if 290 <= t < 345 else 0.0,
    )
    core = run(records)
    assert core.closed_trades
    trade = core.closed_trades[0]
    assert trade["side"] == "no" and trade["reason"] == "TAKE_PROFIT"
    assert trade["net_cents"] > 0


def test_reversal_hits_stop_after_confirmation() -> None:
    walk = quiet_walk()

    def spike_and_fail(t: float) -> float:
        if t < 300:
            return walk(t)
        if t < 310:
            return 50 + (t - 300)
        if t < 318:
            return 60 - (t - 310) * 1.5
        return 47.0

    records = build_stream(
        TICKER, SERIES, 420, spike_and_fail,
        trades_at=surge_volume(290, 320),
        yes_share_at=lambda t: 0.95 if 290 <= t < 309 else 0.5,
        tilt_at=lambda t: 0.3 if 290 <= t < 309 else 0.0,
    )
    core = run(records)
    assert core.closed_trades
    trade = core.closed_trades[0]
    assert trade["reason"] in {"STOP_LOSS", "HARD_STOP"}
    assert trade["net_cents"] < 0


def test_chop_never_trades() -> None:
    def chop(t: float) -> float:
        return 50 + (3 if int(t // 5) % 2 else -3)

    records = build_stream(TICKER, SERIES, 600, chop, trades_at=lambda t: 6)
    core = run(records)
    assert core.closed_trades == []
    assert not core.positions


def test_thin_market_quote_jump_is_watch_only() -> None:
    def jump(t: float) -> float:
        return 50.0 if t < 300 else 62.0

    records = build_stream(TICKER, SERIES, 420, jump, trades_at=lambda t: 1, trade_size=1, depth=10)
    core = run(records)
    stats = core.profiles[SERIES].stats(T0 + 400, core.cfg)
    assert stats.tier == THIN
    assert core.closed_trades == [] and not core.positions

    # Even when THIN trading is allowed, a quote jump with no volume is rejected.
    cfg = ScalperConfig()
    cfg.tiers[THIN].tradeable = True
    core = replay_records(records, cfg)
    assert core.closed_trades == [] and not core.positions


def test_exits_before_close() -> None:
    walk = quiet_walk()

    def late(t: float) -> float:
        if t < 700:
            return walk(t)
        if t < 708:
            return 50 + (t - 700)
        return 58.0

    records = build_stream(
        TICKER, SERIES, 15 * 60 - 1, late,
        trades_at=surge_volume(690, 712),
        yes_share_at=lambda t: 0.95 if 690 <= t < 712 else 0.5,
        tilt_at=lambda t: 0.3 if 690 <= t < 712 else 0.0,
    )
    core = run(records)
    assert core.closed_trades
    assert core.closed_trades[0]["reason"] == "PRE_CLOSE"


def test_held_into_close_settles_from_result() -> None:
    records = build_stream(
        TICKER, SERIES, 15 * 60 - 1, breakout_up,
        trades_at=surge_volume(290, 345),
        yes_share_at=lambda t: 0.95 if 290 <= t < 345 else 0.5,
        tilt_at=lambda t: 0.3 if 290 <= t < 345 else 0.0,
        result="yes",
    )
    # Kill every YES bid shortly after the entry: the position cannot be sold.
    entry_core = run([r for r in records if r.get("rt", 0) <= T0 + 312])
    assert entry_core.positions
    for record in records:
        m = record.get("m")
        if m and m["type"] == "orderbook_snapshot" and record["rt"] > T0 + 312:
            m["msg"]["yes_dollars_fp"] = []
    core = run(records)
    assert core.closed_trades
    trade = core.closed_trades[0]
    assert trade["reason"] == "SETTLEMENT_WIN"
    assert trade["exit_price"] == 100 and trade["exit_fee"] == 0


def test_daily_loss_limit_blocks_entries() -> None:
    records = build_stream(
        TICKER, SERIES, 420, breakout_up,
        trades_at=surge_volume(290, 345),
        yes_share_at=lambda t: 0.95 if 290 <= t < 345 else 0.5,
        tilt_at=lambda t: 0.3 if 290 <= t < 345 else 0.0,
    )
    core = replay_records(records[:5], ScalperConfig(daily_loss_limit_cents=1))
    core.daily_net_cents = -10  # same Central day as the replay clock
    for record in records[5:]:
        if "m" in record:
            core.on_message(record["m"], record["rt"])
        assert core.step(record["rt"]) == [], "entered despite daily loss limit"
    assert "DAILY_LOSS_LIMIT" in core.last_reason.values()


def test_order_errors_pause_entries() -> None:
    cfg = ScalperConfig(max_order_errors=2)
    core = ScalperCore(cfg)
    core.add_market(MarketInfo(TICKER, SERIES, T0, T0 + 900), T0)
    for i in range(2):
        intent = Intent(i, TICKER, "buy", "yes", 1, 50, "ENTRY")
        core.pending_orders[TICKER] = intent
        core.on_order_failed(intent, "boom", T0 + i)
    assert core._paused_until > T0 + 200


def test_partial_exit_keeps_remaining_position() -> None:
    core = ScalperCore(ScalperConfig())
    core.add_market(MarketInfo(TICKER, SERIES, T0, T0 + 900), T0)
    buy = Intent(1, TICKER, "buy", "yes", 5, 51, "ENTRY")
    core.pending_orders[TICKER] = buy
    core.on_fill(buy, Fill(5, 50.0, 4), T0)
    sell = Intent(2, TICKER, "sell", "yes", 5, 60, "TAKE_PROFIT")
    core.pending_orders[TICKER] = sell
    core.on_fill(sell, Fill(2, 60.0, 1), T0 + 10)
    assert core.positions[TICKER].remaining == 3
    sell2 = Intent(3, TICKER, "sell", "yes", 3, 60, "TAKE_PROFIT")
    core.on_fill(sell2, Fill(3, 61.0, 2), T0 + 11)
    trade = core.closed_trades[0]
    assert trade["gross_cents"] == (2 * 60 + 3 * 61) - 5 * 50
    assert trade["net_cents"] == trade["gross_cents"] - (4 + 1 + 2)


# ------------------------------------------------- recording and replay
def test_recorder_replay_and_report_round_trip(tmp_path: Path) -> None:
    records = build_stream(
        TICKER, SERIES, 15 * 60 - 1, breakout_up,
        trades_at=surge_volume(290, 345),
        yes_share_at=lambda t: 0.95 if 290 <= t < 345 else 0.5,
        tilt_at=lambda t: 0.3 if 290 <= t < 345 else 0.0,
        result="yes",
    )
    rec = Recorder(tmp_path)
    core = ScalperCore(ScalperConfig(), listener=lambda kind, data: (
        rec.trade(data) if kind == "exit" else None, rec.event(kind, data, T0)))
    broker = PaperBroker()
    next_tick = T0
    for record in records:
        rt = record["rt"]
        if "market" in record:
            core.add_market(MarketInfo.from_dict(record["market"]), rt)
            rec.market(record["market"], rt)
        elif "m" in record:
            core.on_message(record["m"], rt)
            rec.message(record["m"], rt)
        elif "result" in record:
            rec.result(TICKER, SERIES, record["result"]["result"], rt)
            core.settle(TICKER, record["result"]["result"], rt)
        if rt >= next_tick:
            for intent in core.step(rt):
                state = core.markets[intent.ticker]
                core.on_fill(intent, asyncio.run(broker.execute(intent, state.book)), rt)
            rec.ticks(core.tick_rows(rt), rt)
            next_tick = rt + 1.0
    rec.close()

    raw_file = next((tmp_path / "raw").glob("*.jsonl.gz"))
    assert len(read_raw(raw_file)) == len(records)
    replayed = replay_files([raw_file], ScalperConfig())
    assert replayed.closed_trades and replayed.closed_trades[0]["reason"] == "TAKE_PROFIT"

    summary = trade_summary(tmp_path)
    assert summary["tier"][0]["tier"] == HIGH
    liquidity = liquidity_summary(tmp_path)
    assert liquidity[0]["series"] == SERIES
    holds = hold_rate_at(tmp_path, 60)
    assert holds and holds[0]["series"] == "ALL" and holds[0]["held_%"] == 100.0


def test_truncated_raw_file_is_tolerated(tmp_path: Path) -> None:
    path = tmp_path / "x.jsonl.gz"
    with gzip.open(path, "wt") as handle:
        handle.write(json.dumps({"rt": 1, "m": snapshot(TICKER, 50, 10, 0, 1)}) + "\n")
    data = path.read_bytes()
    path.write_bytes(data + data[: len(data) // 2])  # second member cut off
    assert len(read_raw(path)) >= 1


def test_shutdown_flatten_sells_open_positions() -> None:
    core = ScalperCore(ScalperConfig())
    core.add_market(MarketInfo(TICKER, SERIES, T0, T0 + 900), T0)
    core.on_message(snapshot(TICKER, 55, 50, 0.0, 1), T0)
    buy = Intent(1, TICKER, "buy", "yes", 2, 51, "ENTRY")
    core.pending_orders[TICKER] = buy
    core.on_fill(buy, Fill(2, 50.0, 2), T0)
    intents = core.flatten_intents()
    assert len(intents) == 1
    sell = intents[0]
    assert sell.action == "sell" and sell.count == 2 and sell.limit_price == 55 - 3
    assert core.flatten_intents() == []  # already pending
    core.on_fill(sell, simulate_ioc(sell, core.markets[TICKER].book), T0 + 5)
    assert not core.positions and core.closed_trades[0]["reason"] == "SHUTDOWN"
