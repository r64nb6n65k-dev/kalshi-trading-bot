"""Summaries of recorded scalper data.

* Scalp performance overall, by liquidity tier, series and exit reason.
* Liquidity profile of each series (to tune the tier thresholds).
* Hold rate: when one side first trades at >= 90c, how often does it win,
  by series and time left.
"""

from __future__ import annotations

import csv
import gzip
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


def _rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _tick_rows(data_dir: Path):
    for path in sorted((data_dir / "ticks").glob("*.csv.gz")):
        try:
            with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
                yield from csv.DictReader(handle)
        except (EOFError, OSError):
            continue


def _num(value: str | None) -> float | None:
    try:
        return float(value) if value not in (None, "") else None
    except ValueError:
        return None


def trade_summary(data_dir: Path) -> dict[str, list[dict[str, Any]]]:
    trades = _rows(data_dir / "scalper_trades.csv")
    out: dict[str, list[dict[str, Any]]] = {}
    for key in ("mode", "tier", "series", "reason"):
        groups: dict[str, list[float]] = defaultdict(list)
        for t in trades:
            groups[t.get(key, "") or "-"].append(float(t["net_cents"]))
        table = []
        for name, nets in sorted(groups.items()):
            wins = [n for n in nets if n > 0]
            losses = [n for n in nets if n <= 0]
            table.append({
                key: name,
                "trades": len(nets),
                "win_rate": round(100 * len(wins) / len(nets), 1),
                "net_$": round(sum(nets) / 100, 2),
                "avg_win_c": round(statistics.mean(wins), 1) if wins else 0,
                "avg_loss_c": round(statistics.mean(losses), 1) if losses else 0,
            })
        out[key] = table
    return out


def liquidity_summary(data_dir: Path) -> list[dict[str, Any]]:
    per: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    tiers: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for row in _tick_rows(data_dir):
        series = row["series"]
        for col in ("trade_rate", "spread", "yes_depth", "no_depth", "typical_move"):
            value = _num(row.get(col))
            if value is not None:
                per[series][col].append(value)
        tiers[series][row.get("tier", "")] += 1
    table = []
    for series, cols in sorted(per.items()):
        depth = [a + b for a, b in zip(cols["yes_depth"], cols["no_depth"], strict=False)]
        total = sum(tiers[series].values()) or 1
        table.append({
            "series": series,
            "trade_rate/min": round(statistics.median(cols["trade_rate"]), 1) if cols["trade_rate"] else None,
            "spread": statistics.median(cols["spread"]) if cols["spread"] else None,
            "depth": round(statistics.median(depth)) if depth else None,
            "typical_30s_move": round(statistics.median(cols["typical_move"]), 2) if cols["typical_move"] else None,
            "tier_mix": " ".join(f"{k}:{100 * v // total}%" for k, v in sorted(tiers[series].items())),
        })
    return table


def hold_rate_at(data_dir: Path, level: int = 90) -> list[dict[str, Any]]:
    results = {r["ticker"]: r["result"] for r in _rows(data_dir / "market_results.csv")}
    first_touch: dict[str, tuple[str, str, float]] = {}
    for row in _tick_rows(data_dir):
        ticker = row["ticker"]
        if ticker in first_touch or ticker not in results:
            continue
        ask, bid = _num(row.get("yes_ask")), _num(row.get("yes_bid"))
        left = _num(row.get("seconds_left"))
        if ask is None or bid is None or left is None or left <= 0:
            continue
        if ask >= level:
            first_touch[ticker] = (row["series"], "yes", left)
        elif 100 - bid >= level:
            first_touch[ticker] = (row["series"], "no", left)

    buckets = [(0, 60, "<1m"), (60, 180, "1-3m"), (180, 300, "3-5m"), (300, 600, "5-10m"), (600, 10**6, "10m+")]
    stats: dict[tuple[str, str], list[int]] = defaultdict(lambda: [0, 0])
    for ticker, (series, side, left) in first_touch.items():
        label = next(lbl for lo, hi, lbl in buckets if lo <= left < hi)
        held = int(results[ticker] == side)
        for key in ((series, label), ("ALL", label)):
            stats[key][0] += 1
            stats[key][1] += held
    order = {lbl: i for i, (_, _, lbl) in enumerate(buckets)}
    return [
        {"series": s, "time_left": lbl, "markets": n, "held_%": round(100 * h / n, 1)}
        for (s, lbl), (n, h) in sorted(stats.items(), key=lambda kv: (kv[0][0] != "ALL", kv[0][0], order[kv[0][1]]))
    ]
