"""Momentum features and the entry decision.

A long entry needs all of these at once:

* price moving fast (30s mid move above both a floor and a multiple of the
  market's own typical 30s move),
* the move still going (10s move not against it) and not already exhausted,
* the last 15 seconds moving mostly one way (size-weighted consistency),
* real taker volume confirming it, above the market's normal volume,
* the order book leaning the same way,
* a tight enough spread and room left to the take-profit target.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from kalshi_bot.momentum_scalper.config import ScalperConfig, TierRules
from kalshi_bot.momentum_scalper.market_state import ProfileStats, TickerState, side_depth


@dataclass(slots=True)
class Features:
    yes_bid: int | None
    yes_ask: int | None
    spread: int | None
    mid: float | None
    move_fast: float | None
    move: float | None
    move_slow: float | None
    up_cents: float
    down_cents: float
    yes_flow: int
    no_flow: int
    yes_depth: int
    no_depth: int
    seconds_left: float
    age: float

    @property
    def imbalance(self) -> float:
        total = self.yes_depth + self.no_depth
        return 0.0 if total == 0 else (self.yes_depth - self.no_depth) / total

    @property
    def flow_ratio(self) -> float:
        total = self.yes_flow + self.no_flow
        return 0.0 if total == 0 else (self.yes_flow - self.no_flow) / total

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["imbalance"] = round(self.imbalance, 4)
        data["flow_ratio"] = round(self.flow_ratio, 4)
        return data


@dataclass(slots=True)
class Signal:
    side: str  # "yes" or "no"
    ask: int
    threshold: float
    detail: str


def compute_features(state: TickerState, now: float, cfg: ScalperConfig) -> Features:
    mid = state.mid()

    def move(window: float) -> float | None:
        if mid is None or not state.history_covers(window, now):
            return None
        past = state.mid_at(now - window)
        return None if past is None else mid - past

    # Size-weighted consistency over the recent part of the move: how much of
    # the path went with the move vs against it. Measured over a shorter window
    # than the move itself so a clean breakout out of a choppy range qualifies.
    up = down = 0.0
    window = cfg.consistency_window
    if mid is not None and state.history_covers(window, now):
        step = window / 6.0
        prev = state.mid_at(now - window)
        t = now - window + step
        while t <= now + 1e-9 and prev is not None:
            current = state.mid_at(t)
            if current is not None:
                if current > prev:
                    up += current - prev
                elif current < prev:
                    down += prev - current
                prev = current
            t += step

    yes_flow, no_flow = state.flow(cfg.flow_window, now)
    return Features(
        yes_bid=state.book.yes_bid,
        yes_ask=state.book.yes_ask,
        spread=state.book.spread,
        mid=mid,
        move_fast=move(cfg.fast_window),
        move=move(cfg.move_window),
        move_slow=move(cfg.slow_window),
        up_cents=up,
        down_cents=down,
        yes_flow=yes_flow,
        no_flow=no_flow,
        yes_depth=side_depth(state.book, "yes", cfg.depth_band_cents),
        no_depth=side_depth(state.book, "no", cfg.depth_band_cents),
        seconds_left=state.seconds_left(now),
        age=state.age(now),
    )


def evaluate(
    f: Features,
    profile: ProfileStats,
    rules: TierRules,
    cfg: ScalperConfig,
) -> tuple[Signal | None, str]:
    """Return (signal, reason). ``reason`` explains a rejection."""
    if f.yes_bid is None or f.yes_ask is None or f.spread is None or f.mid is None:
        return None, "BOOK_ONE_SIDED"
    if f.move is None or f.move_fast is None:
        return None, "HISTORY_SHORT"
    if f.spread > rules.max_spread_cents:
        return None, f"SPREAD_WIDE {f.spread}c>{rules.max_spread_cents}c"

    threshold = max(rules.min_move_cents, rules.vol_multiple * profile.typical_move)
    if abs(f.move) < threshold:
        return None, f"NO_MOMENTUM move={f.move:+.1f}c need={threshold:.1f}c"

    side = "yes" if f.move > 0 else "no"
    sign = 1 if side == "yes" else -1

    if sign * f.move_fast < 0:
        return None, f"FADING move_fast={f.move_fast:+.1f}c"
    if f.move_slow is not None and abs(f.move_slow) > cfg.max_run_cents:
        return None, f"EXHAUSTED move_60s={f.move_slow:+.1f}c"

    with_move = f.up_cents if side == "yes" else f.down_cents
    against_move = f.down_cents if side == "yes" else f.up_cents
    moving = with_move + against_move
    consistency = with_move / moving if moving else 0.0
    if consistency < cfg.consistency_min:
        return None, f"CHOPPY consistency={consistency:.2f}"

    directional = f.yes_flow if side == "yes" else f.no_flow
    normal = profile.trade_rate * cfg.flow_window / 60.0
    need_volume = max(rules.min_aggressive_contracts, rules.volume_surge * normal)
    if directional < need_volume:
        return None, f"NO_VOLUME taker={directional} need={need_volume:.0f}"
    if sign * f.flow_ratio < rules.min_flow_ratio:
        return None, f"FLOW_MIXED ratio={sign * f.flow_ratio:+.2f}"
    if sign * f.imbalance < rules.min_book_imbalance:
        return None, f"BOOK_AGAINST imbalance={sign * f.imbalance:+.2f}"

    ask = f.yes_ask if side == "yes" else 100 - f.yes_bid
    if ask < cfg.min_entry_price or ask > cfg.max_entry_price:
        return None, f"PRICE_OUT_OF_RANGE {side}_ask={ask}c"
    if ask + cfg.take_profit_cents > 99:
        return None, f"NO_ROOM {side}_ask={ask}c"

    detail = (
        f"{side.upper()} ask={ask}c move30={f.move:+.1f}c move10={f.move_fast:+.1f}c "
        f"need={threshold:.1f}c consistency={consistency:.2f} taker={directional} "
        f"flow={sign * f.flow_ratio:+.2f} book={sign * f.imbalance:+.2f} spread={f.spread}c"
    )
    return Signal(side, ask, threshold, detail), "SIGNAL"
