"""Live/paper runner: market discovery, WebSocket feed, step loop, settlement."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from datetime import datetime
from typing import Any

from kalshi_bot.momentum_scalper.brokers import Broker
from kalshi_bot.momentum_scalper.core import Fill, Intent, ScalperCore
from kalshi_bot.momentum_scalper.market_state import MarketInfo
from kalshi_bot.momentum_scalper.recorder import Recorder

logger = logging.getLogger(__name__)

SERIES_PATTERN = re.compile(r"KX[A-Z0-9]+15M")


def _ts(raw: str | None) -> float | None:
    if not raw:
        return None
    return datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp()


class ScalperRunner:
    def __init__(
        self,
        client: Any,
        websocket: Any,
        core: ScalperCore,
        broker: Broker,
        recorder: Recorder | None,
        categories: tuple[str, ...] = ("Crypto", "Commodities"),
        series: tuple[str, ...] = (),
        step_seconds: float = 0.5,
        dashboard: bool = True,
    ) -> None:
        self.client = client
        self.websocket = websocket
        self.core = core
        self.broker = broker
        self.recorder = recorder
        self.categories = categories
        self.fixed_series = tuple(s.upper() for s in series)
        self.step_seconds = step_seconds
        self.dashboard = dashboard
        self.series: set[str] = set(self.fixed_series)
        self._series_refreshed = 0.0
        self._ws: Any = None
        self._ws_ids = 0
        self._subscribed: set[str] = set()
        self._awaiting_result: dict[str, tuple[str, float]] = {}
        self._stop = asyncio.Event()
        self._seq: dict[int, int] = {}
        self._last_reconnect = 0.0
        self._last_tick_write = 0.0
        self._last_status = 0.0
        self.discover_every = 5.0
        self.settle_every = 20.0
        core.listener = self._on_core_event

    # ------------------------------------------------------------ events
    def _on_core_event(self, kind: str, data: dict[str, Any]) -> None:
        now = time.time()
        if self.recorder is not None:
            if kind == "exit":
                self.recorder.trade(data)
            self.recorder.event(kind, data, now)
        if not self.dashboard:
            return
        try:
            from kalshi_bot import dashboard as dash

            mode = f"scalp-{self.core.mode}"
            if kind == "entry":
                dash.record_entry(
                    data["ticker"], data["side"], int(round(data["price"])), data["count"],
                    data.get("seconds_left"), data.get("stop"), data.get("target"), mode,
                )
            elif kind == "exit":
                dash.record_exit(
                    data["ticker"], data["side"], int(round(data["entry_price"])),
                    int(round(data["exit_price"])), data["reason"], data["count"],
                    data["net_cents"], self.core.stats.net_cents,
                )
            elif kind == "signal":
                dash.record_model_snapshot(ticker=data["ticker"], decision="SIGNAL", reason=data["detail"])
        except Exception:
            logger.exception("dashboard update failed")

    # -------------------------------------------------------- discovery
    async def _refresh_series(self, now: float) -> None:
        if self.fixed_series or now - self._series_refreshed < 600:
            return
        found: set[str] = set()
        for category in self.categories:
            try:
                data = await self.client._request("GET", "/series", params={"category": category})
            except Exception:
                logger.exception("series discovery failed | %s", category)
                continue
            for item in data.get("series", []):
                ticker = str(item.get("ticker", "")).upper()
                if SERIES_PATTERN.fullmatch(ticker):
                    found.add(ticker)
        if found:
            if found != self.series:
                logger.warning("SCALPER SERIES | %d | %s", len(found), sorted(found))
            self.series = found
            self._series_refreshed = now

    def _needs_refresh(self, series: str, now: float) -> bool:
        current = [s for s in self.core.markets.values() if s.info.series == series and s.info.close_ts > now]
        return not current or min(s.info.close_ts for s in current) - now < 30

    async def discover(self) -> None:
        semaphore = asyncio.Semaphore(4)
        full_refresh_at = 0.0
        while not self._stop.is_set():
            now = time.time()
            await self._refresh_series(now)
            full = now >= full_refresh_at
            if full:
                full_refresh_at = now + 120

            async def fetch(series: str) -> None:
                async with semaphore:
                    try:
                        markets = await self.client.get_markets(status="open", series_ticker=series, limit=20)
                    except Exception:
                        logger.exception("market poll failed | %s", series)
                        return
                for market in markets:
                    open_ts, close_ts = _ts(market.open_time), _ts(market.close_time)
                    if close_ts is None or close_ts <= time.time():
                        continue
                    if open_ts is not None and open_ts > time.time() + 5:
                        continue
                    self._add_market(MarketInfo(
                        ticker=market.ticker,
                        series=series,
                        open_ts=open_ts or time.time(),
                        close_ts=close_ts,
                        exchange_index=market.exchange_index,
                        floor_strike=market.floor_strike,
                    ))

            targets = [s for s in sorted(self.series) if full or self._needs_refresh(s, now)]
            await asyncio.gather(*(fetch(s) for s in targets))
            self._expire_markets(time.time())
            new = [t for t in self._active_tickers() if t not in self._subscribed]
            if new and self._ws is not None:
                try:
                    await self._subscribe(new)
                except Exception:
                    logger.exception("subscribe failed")
            await self._sleep(self.discover_every)

    def _add_market(self, info: MarketInfo) -> None:
        if info.ticker in self.core.markets:
            return
        now = time.time()
        self.core.add_market(info, now)
        if self.recorder is not None:
            self.recorder.market(info.to_dict(), now)
        logger.info("MARKET ADDED | %s closes in %.0fs", info.ticker, info.close_ts - now)

    def _expire_markets(self, now: float) -> None:
        for ticker, state in list(self.core.markets.items()):
            if state.info.close_ts <= now and ticker not in self._awaiting_result:
                self._awaiting_result[ticker] = (state.info.series, now)
            if state.info.close_ts + 5 <= now:
                self.core.drop_market(ticker)

    # -------------------------------------------------------- settlement
    async def settlements(self) -> None:
        while not self._stop.is_set():
            await self._sleep(self.settle_every)
            for ticker, (series, closed_at) in list(self._awaiting_result.items()):
                try:
                    market = await self.client.get_market(ticker)
                except Exception:
                    logger.exception("settlement poll failed | %s", ticker)
                    continue
                result = (market.result or "").lower()
                if result in {"yes", "no"}:
                    now = time.time()
                    self._awaiting_result.pop(ticker, None)
                    if self.recorder is not None:
                        self.recorder.result(ticker, series, result, now)
                    self.core.settle(ticker, result, now)
                    self.core.drop_market(ticker)
                elif time.time() - closed_at > 3 * 3600:
                    logger.warning("giving up on settlement result for %s", ticker)
                    self._awaiting_result.pop(ticker, None)

    # --------------------------------------------------------- websocket
    async def feed(self) -> None:
        import websockets

        backoff = 1.0
        while not self._stop.is_set():
            tickers = self._active_tickers()
            if not tickers:
                await self._sleep(1.0)
                continue
            try:
                headers = self.websocket._handshake_headers()
                async with websockets.connect(
                    self.websocket._ws_url, additional_headers=headers, ping_interval=10, max_size=None
                ) as ws:
                    self._ws = ws
                    self._subscribed = set()
                    self._seq = {}
                    self.core.reset_books()
                    if self.recorder is not None:
                        self.recorder.reset(time.time())
                    await self._subscribe(tickers)
                    logger.warning("WEBSOCKET CONNECTED | %d markets", len(tickers))
                    backoff = 1.0
                    async for raw in ws:
                        now = time.time()
                        message = json.loads(raw)
                        if self._sequence_gap(message):
                            logger.warning("ORDERBOOK SEQUENCE GAP | reconnecting")
                            break
                        kind = message.get("type")
                        if kind == "error":
                            logger.error("WEBSOCKET ERROR | %s", message)
                            continue
                        if kind in {"orderbook_snapshot", "orderbook_delta", "trade"}:
                            self.core.on_message(message, now)
                            if self.recorder is not None:
                                self.recorder.message(message, now)
                        new = [t for t in self._active_tickers() if t not in self._subscribed]
                        if new:
                            await self._subscribe(new)
                        if self._stop.is_set():
                            break
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("websocket failed; reconnecting in %.0fs", backoff)
            finally:
                self._ws = None
            if self._stop.is_set():
                break
            self.core.reset_books()
            if self.recorder is not None:
                self.recorder.reset(time.time())
            await self._sleep(backoff)
            backoff = min(30.0, backoff * 2)

    def _active_tickers(self) -> list[str]:
        now = time.time()
        return sorted(t for t, s in self.core.markets.items() if s.info.close_ts > now)

    async def _subscribe(self, tickers: list[str]) -> None:
        if self._ws is None or not tickers:
            return
        self._ws_ids += 1
        await self._ws.send(json.dumps({
            "id": self._ws_ids,
            "cmd": "subscribe",
            "params": {"channels": ["orderbook_delta", "trade"], "market_tickers": tickers},
        }))
        self._subscribed.update(tickers)

    def _sequence_gap(self, message: dict[str, Any]) -> bool:
        if message.get("type") not in {"orderbook_snapshot", "orderbook_delta"}:
            return False
        sid, seq = message.get("sid"), message.get("seq")
        if sid is None or seq is None:
            return False
        last = self._seq.get(sid)
        self._seq[sid] = int(seq)
        return last is not None and int(seq) != last + 1

    # -------------------------------------------------------------- step
    async def stepper(self) -> None:
        while not self._stop.is_set():
            now = time.time()
            for intent in self.core.step(now):
                asyncio.create_task(self._execute(intent))
            if self.recorder is not None:
                if now - self._last_tick_write >= 1.0:
                    self.recorder.ticks(self.core.tick_rows(now), now)
                    self._last_tick_write = now
                self.recorder.maybe_flush()
            if now - self._last_status >= 60:
                self._last_status = now
                self._log_status(now)
            await asyncio.sleep(self.step_seconds)

    async def _execute(self, intent: Intent) -> None:
        state = self.core.markets.get(intent.ticker)
        book = state.book if state else None
        try:
            fill = await self.broker.execute(intent, book)
        except Exception as exc:  # live API error
            self.core.on_order_failed(intent, repr(exc), time.time())
            return
        self.core.on_fill(intent, fill if fill else Fill(0, 0.0, 0), time.time())

    def _log_status(self, now: float) -> None:
        tiers: dict[str, list[str]] = {}
        for series, profile in self.core.profiles.items():
            stats = profile.stats(now, self.core.cfg)
            tiers.setdefault(stats.tier, []).append(
                f"{series}(rate={stats.trade_rate:.0f}/m spread={stats.spread} depth={stats.depth})"
            )
        s = self.core.summary()
        logger.warning(
            "SCALPER %s | trades=%d win=%.1f%% net=%+dc today=%+dc open=%d | %s",
            self.core.mode.upper(), s["trades"], s["win_rate"], s["net_cents"],
            self.core.daily_net_cents, s["open_positions"],
            " ".join(f"{k}: {', '.join(v)}" for k, v in sorted(tiers.items())),
        )

    # --------------------------------------------------------------- run
    async def _sleep(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=seconds)
        except TimeoutError:
            pass

    async def check_existing_positions(self) -> None:
        """Live safety: never trade a market where the account already holds a position."""
        try:
            positions = await self.client.get_positions(count_filter="position")
        except Exception:
            logger.exception("could not read existing positions")
            return
        for pos in positions:
            if pos.position != 0:
                self.core.blocked.add(pos.ticker)
        if self.core.blocked:
            logger.warning("EXISTING POSITIONS (not traded) | %s", sorted(self.core.blocked))

    async def flatten(self) -> None:
        """Best-effort exit of open positions on shutdown (e.g. a redeploy)."""
        for attempt in range(3):
            intents = self.core.flatten_intents()
            if not intents:
                break
            await asyncio.gather(*(self._execute(i) for i in intents))
            await asyncio.sleep(0.5)
        if self.core.positions:
            logger.error(
                "OPEN POSITIONS LEFT AT SHUTDOWN (close manually if live) | %s",
                {t: f"{p.side} x{p.remaining}" for t, p in self.core.positions.items()},
            )

    def _install_signal_handlers(self) -> None:
        import signal

        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, self._stop.set)
            except (NotImplementedError, RuntimeError, ValueError):
                pass

    def _task_done(self, task: asyncio.Task) -> None:
        if task.cancelled():
            return
        exc = task.exception()
        if exc is not None:
            logger.error("scalper task crashed; shutting down so the host restarts it", exc_info=exc)
            self._stop.set()

    async def run(self, max_seconds: float | None = None) -> None:
        self._install_signal_handlers()
        if self.core.mode == "live":
            await self.check_existing_positions()
        tasks = [
            asyncio.create_task(self.discover()),
            asyncio.create_task(self.feed()),
            asyncio.create_task(self.stepper()),
            asyncio.create_task(self.settlements()),
        ]
        for task in tasks:
            task.add_done_callback(self._task_done)
        try:
            if max_seconds:
                await self._sleep(max_seconds)
            else:
                await self._stop.wait()
        finally:
            self._stop.set()
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            try:
                await asyncio.wait_for(self.flatten(), timeout=15)
            except Exception:
                logger.exception("flatten on shutdown failed")
            if self.recorder is not None:
                self.recorder.close()
            logger.warning("SCALPER STOPPED | %s", self.core.summary())
