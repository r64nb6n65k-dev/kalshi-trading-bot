"""Kalshi momentum scalper: liquidity-aware, fee-aware, paper by default."""

from kalshi_bot.momentum_scalper.config import ScalperConfig
from kalshi_bot.momentum_scalper.core import ScalperCore

__all__ = ["ScalperConfig", "ScalperCore"]
