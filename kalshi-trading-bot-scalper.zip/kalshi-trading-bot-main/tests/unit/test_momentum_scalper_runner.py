"""Runner plumbing and live-broker tests against a fake Kalshi (no network)."""

from __future__ import annotations

import asyncio
import gzip
import json
import sys
import time
import types
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace

from kalshi_bot.momentum_scalper.brokers import LiveBroker
from kalshi_bot.momentum_scalper.config import ScalperConfig
from kalshi_bot.momentum_scalper.core import Intent, ScalperCore
from kalshi_bot.momentum_scalper.recorder import Recorder, read_raw
from kalshi_bot.momentum_scalper.runner import ScalperRunner

from tests.unit.scalper_sim import snapshot, trade


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, UTC).isoformat().replace("+00:00", "Z")


class FakeClient:
    def __init__(self, now: float) -> None:
        self.closing = SimpleNamespace(
            ticker="KXBTC15M-A", open_time=_iso(now - 897), close_time=_iso(now + 1.5),
            exchange_index=None, floor_strike=1.0,
        )
        self.current = SimpleNamespace(
            ticker="KXBTC15M-B", open_time=_iso(now - 1), close_time=_iso(now + 600),
            exchange_index=3, floor_strike=1.0,
        )
        self.orders: list = []

    async def _request(self, method, path, **kwargs):
        assert path == "/series"
        return {"series": [{"ticker": "KXBTC15M"}, {"ticker": "KXBTCD"}]}

    async def get_markets(self, **params):
        assert params["series_ticker"] == "KXBTC15M"
        return [self.closing, self.current]

    async def get_market(self, ticker):
        return SimpleNamespace(result="yes" if ticker == "KXBTC15M-A" else "")

    async def get_positions(self, **params):
        return [SimpleNamespace(ticker="KXOLD-1", position=3)]

    async def create_order(self, request):
        self.orders.append(request)
        return SimpleNamespace(fill_count=request.count - 1, outcome_fill_price=44)


class FakeConnection:
    def __init__(self) -> None:
        self.subscriptions: list[dict] = []
        self.seq = 0

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return False

    async def send(self, raw: str) -> None:
        self.subscriptions.append(json.loads(raw))

    def __aiter__(self):
        return self._messages()

    async def _messages(self):
        while True:
            await asyncio.sleep(0.05)
            tickers = [t for s in self.subscriptions for t in s["params"]["market_tickers"]]
            for ticker in tickers:
                self.seq += 1
                yield json.dumps(snapshot(ticker, 50, 100, 0.0, self.seq))
                yield json.dumps(trade(ticker, 51, 5, "yes"))


def test_runner_discovers_subscribes_records_and_settles(tmp_path: Path) -> None:
    connection = FakeConnection()
    fake_websockets = types.ModuleType("websockets")
    fake_websockets.connect = lambda url, **kwargs: connection  # type: ignore[attr-defined]
    saved = sys.modules.get("websockets")
    sys.modules["websockets"] = fake_websockets
    try:
        client = FakeClient(time.time())
        core = ScalperCore(ScalperConfig(), mode="live")
        runner = ScalperRunner(
            client=client,
            websocket=SimpleNamespace(_ws_url="wss://fake", _handshake_headers=lambda: {}),
            core=core,
            broker=LiveBroker(client),
            recorder=Recorder(tmp_path),
            dashboard=False,
        )
        runner.discover_every = 0.2
        runner.settle_every = 0.3
        asyncio.run(runner.run(max_seconds=3.5))
    finally:
        if saved is not None:
            sys.modules["websockets"] = saved
        else:
            sys.modules.pop("websockets", None)

    assert runner.series == {"KXBTC15M"}  # KXBTCD is not a 15m series
    assert "KXOLD-1" in core.blocked  # existing account position is never traded
    subscribed = {t for s in connection.subscriptions for t in s["params"]["market_tickers"]}
    assert "KXBTC15M-B" in subscribed
    assert core.markets["KXBTC15M-B"].book.ready
    assert "KXBTC15M-A" not in core.markets  # closed and settled

    raw = read_raw(next((tmp_path / "raw").glob("*.jsonl.gz")))
    assert any("market" in r for r in raw) and any("m" in r for r in raw)
    assert any(r.get("result", {}).get("ticker") == "KXBTC15M-A" for r in raw)
    results = (tmp_path / "market_results.csv").read_text()
    assert "KXBTC15M-A,yes" in results
    with gzip.open(next((tmp_path / "ticks").glob("*.csv.gz")), "rt") as handle:
        ticks = handle.read().splitlines()
    assert len(ticks) > 2 and any("KXBTC15M-B" in line for line in ticks)


def test_live_broker_sends_ioc_with_exchange_index() -> None:
    client = FakeClient(time.time())
    broker = LiveBroker(client)
    intent = Intent(1, "KXBTC15M-B", "buy", "no", 4, 45, "ENTRY", exchange_index=3)
    fill = asyncio.run(broker.execute(intent, None))
    request = client.orders[0]
    assert request.side.value == "no" and request.action.value == "buy"
    assert request.no_price == 45 and request.yes_price is None
    assert request.time_in_force.value == "immediate_or_cancel"
    assert request.exchange_index == 3
    assert fill.count == 3 and fill.avg_price == 44 and fill.fee_cents > 0
