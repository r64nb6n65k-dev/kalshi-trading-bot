"""Order execution: paper (book-walking) and live (Kalshi IOC orders).

Every order is immediate-or-cancel. Momentum entries need to be fast, and
IOC exits avoid managing resting orders that could fill after the bot has
already decided to leave.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Protocol

from kalshi_bot.momentum_scalper.core import Fill, Intent
from kalshi_bot.momentum_scalper.fees import taker_fee_cents, taker_fee_for_levels
from kalshi_bot.momentum_scalper.market_state import ask_levels, bid_levels
from kalshi_bot.scalping.book import BinaryOrderBook

if TYPE_CHECKING:
    from kalshi_bot.exchange.client import KalshiClient

logger = logging.getLogger(__name__)


class Broker(Protocol):
    async def execute(self, intent: Intent, book: BinaryOrderBook | None) -> Fill: ...


def simulate_ioc(intent: Intent, book: BinaryOrderBook, fee_rate: float = 0.07) -> Fill:
    """Fill against displayed liquidity only, never beyond the limit price."""
    if intent.action == "buy":
        levels = [(p, s) for p, s in ask_levels(book, intent.side) if p <= intent.limit_price]
    else:
        levels = [(p, s) for p, s in bid_levels(book, intent.side) if p >= intent.limit_price]
    remaining = intent.count
    taken: list[tuple[int, int]] = []
    for price, size in levels:
        if remaining <= 0:
            break
        qty = min(size, remaining)
        taken.append((price, qty))
        remaining -= qty
    filled = sum(q for _, q in taken)
    if filled == 0:
        return Fill(0, 0.0, 0)
    avg = sum(p * q for p, q in taken) / filled
    return Fill(filled, avg, taker_fee_for_levels(taken, fee_rate))


class PaperBroker:
    """Fills at the displayed book at decision time.

    This is optimistic about latency: a live IOC lands ~100-300ms later, when
    a fast-moving book may have moved. Treat paper results as an upper bound.
    """

    def __init__(self, fee_rate: float = 0.07) -> None:
        self.fee_rate = fee_rate

    async def execute(self, intent: Intent, book: BinaryOrderBook | None) -> Fill:
        if book is None or not book.ready:
            return Fill(0, 0.0, 0)
        return simulate_ioc(intent, book, self.fee_rate)


class LiveBroker:
    def __init__(self, client: KalshiClient, fee_rate: float = 0.07) -> None:
        self.client = client
        self.fee_rate = fee_rate

    async def execute(self, intent: Intent, book: BinaryOrderBook | None) -> Fill:
        from kalshi_bot.exchange.models import Action, OrderRequest, Side, TimeInForce

        side = Side.YES if intent.side == "yes" else Side.NO
        request = OrderRequest(
            ticker=intent.ticker,
            action=Action.BUY if intent.action == "buy" else Action.SELL,
            side=side,
            count=intent.count,
            yes_price=intent.limit_price if side is Side.YES else None,
            no_price=intent.limit_price if side is Side.NO else None,
            time_in_force=TimeInForce.IMMEDIATE_OR_CANCEL,
            exchange_index=intent.exchange_index,
        )
        order = await self.client.create_order(request)
        filled = int(order.fill_count or 0)
        if filled <= 0:
            return Fill(0, 0.0, 0)
        price = order.outcome_fill_price
        if price is None:
            # Fall back to the limit, which is the worst price IOC could fill at.
            price = intent.limit_price
            logger.warning("No fill price returned for %s; booking at limit %dc", intent.ticker, price)
        # Kalshi does not return the fee on the order response; estimate it with
        # the published taker formula. Reconcile against account fills if needed.
        return Fill(filled, float(price), taker_fee_cents(filled, int(round(price)), self.fee_rate))
