"""Exchange-independent scalper logic.

The core never talks to Kalshi. It consumes WebSocket messages and a clock,
and returns order *intents*. A broker (paper or live) executes each intent
and reports the fill back. The same core therefore runs live, in paper mode,
and in ``scalper-replay`` over recorded data, with identical decisions.
"""

from __future__ import annotations

import itertools
import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from typing import Any
from zoneinfo import ZoneInfo

from kalshi_bot.momentum_scalper.config import WARMUP, ScalperConfig
from kalshi_bot.momentum_scalper.market_state import (
    MarketInfo,
    SeriesProfile,
    TickerState,
    parse_trade,
)
from kalshi_bot.momentum_scalper.signals import Features, compute_features, evaluate

logger = logging.getLogger(__name__)
_CENTRAL = ZoneInfo("America/Chicago")

Listener = Callable[[str, dict[str, Any]], None]


@dataclass(slots=True)
class Intent:
    intent_id: int
    ticker: str
    action: str  # "buy" | "sell"
    side: str  # "yes" | "no"
    count: int
    limit_price: int  # outcome price in cents
    reason: str
    exchange_index: int | None = None


@dataclass(slots=True)
class Fill:
    count: int
    avg_price: float
    fee_cents: int


@dataclass(slots=True)
class Position:
    ticker: str
    series: str
    side: str
    tier: str
    count: int
    entry_price: float
    entry_fee: int
    entry_ts: float
    features: dict[str, Any]
    profile: dict[str, Any]
    exit_proceeds: float = 0.0
    exit_fees: int = 0
    exited: int = 0
    stop_streak: int = 0
    last_stop_check: float = 0.0
    peak_bid: int = 0
    trough_bid: int = 100
    awaiting_settlement: bool = False
    last_exit_reason: str = ""

    @property
    def remaining(self) -> int:
        return self.count - self.exited


@dataclass(slots=True)
class PendingSignal:
    side: str
    first_ts: float
    first_ask: int
    last_ts: float
    streak: int


@dataclass(slots=True)
class CoreStats:
    trades: int = 0
    wins: int = 0
    losses: int = 0
    net_cents: int = 0
    fees_cents: int = 0


class ScalperCore:
    def __init__(
        self,
        cfg: ScalperConfig,
        mode: str = "paper",
        listener: Listener | None = None,
    ) -> None:
        self.cfg = cfg
        self.mode = mode
        self.listener = listener
        self.markets: dict[str, TickerState] = {}
        self.profiles: dict[str, SeriesProfile] = {}
        self.positions: dict[str, Position] = {}
        self.pending_orders: dict[str, Intent] = {}
        self.pending_signals: dict[str, PendingSignal] = {}
        self.cooldown_until: dict[str, float] = {}
        self.entries: dict[str, int] = {}
        self.blocked: set[str] = set()
        self.stats = CoreStats()
        self.closed_trades: list[dict[str, Any]] = []
        self._ids = itertools.count(1)
        self._day: date | None = None
        self.daily_net_cents = 0
        self._order_errors = 0
        self._paused_until = 0.0
        self.last_reason: dict[str, str] = {}
        self._entry_context: dict[int, dict[str, Any]] = {}

    # ------------------------------------------------------------------ io
    def _emit(self, kind: str, data: dict[str, Any]) -> None:
        if self.listener is not None:
            try:
                self.listener(kind, data)
            except Exception:  # never let telemetry break trading
                logger.exception("listener failed for %s", kind)

    def add_market(self, info: MarketInfo, now: float) -> None:
        if info.ticker in self.markets:
            return
        self.markets[info.ticker] = TickerState.create(info, now)
        self.profiles.setdefault(info.series, SeriesProfile(info.series, now))

    def drop_market(self, ticker: str) -> None:
        if ticker in self.positions or ticker in self.pending_orders:
            return
        self.markets.pop(ticker, None)
        self.pending_signals.pop(ticker, None)
        self.cooldown_until.pop(ticker, None)
        self.entries.pop(ticker, None)
        self.last_reason.pop(ticker, None)

    def reset_books(self) -> None:
        """Called after a reconnect; books stay unusable until a new snapshot."""
        for state in self.markets.values():
            state.book.ready = False
            state.book.yes.clear()
            state.book.no.clear()
            state.book.sequence = 0
            state.mids.clear()
        self.pending_signals.clear()

    def on_message(self, message: dict[str, Any], now: float) -> None:
        payload = message.get("msg") or {}
        ticker = payload.get("market_ticker")
        state = self.markets.get(ticker) if ticker else None
        if state is None:
            return
        kind = message.get("type")
        if kind in ("orderbook_snapshot", "orderbook_delta"):
            state.book.apply(message)
        elif kind == "trade":
            trade = parse_trade(payload, now)
            if trade is not None:
                state.trades.append(trade)
                self.profiles[state.info.series].on_trade(trade)

    # ---------------------------------------------------------------- loop
    def step(self, now: float) -> list[Intent]:
        self._roll_day(now)
        intents: list[Intent] = []
        for ticker, state in list(self.markets.items()):
            state.sample(now)
            if state.book.ready:
                self.profiles[state.info.series].sample(state, now, self.cfg.depth_band_cents)
            if ticker in self.pending_orders:
                continue
            position = self.positions.get(ticker)
            if position is not None:
                self.last_reason[ticker] = f"HOLDING {position.side.upper()} x{position.remaining}"
                intent = self._manage(position, state, now)
            else:
                intent = self._consider_entry(state, now)
            if intent is not None:
                self.pending_orders[ticker] = intent
                intents.append(intent)
        return intents

    def tick_rows(self, now: float) -> list[dict[str, Any]]:
        """One row per market for the data recorder."""
        rows = []
        for ticker, state in self.markets.items():
            if not state.book.ready:
                continue
            f = compute_features(state, now, self.cfg)
            stats = self.profiles[state.info.series].stats(now, self.cfg)
            position = self.positions.get(ticker)
            rows.append({
                "ts": round(now, 3),
                "series": state.info.series,
                "ticker": ticker,
                "seconds_left": round(f.seconds_left, 1),
                "yes_bid": f.yes_bid,
                "yes_ask": f.yes_ask,
                "spread": f.spread,
                "yes_bid_size": state.book.bid_size("yes"),
                "yes_ask_size": state.book.ask_size("yes"),
                "yes_depth": f.yes_depth,
                "no_depth": f.no_depth,
                "move_10s": _r(f.move_fast),
                "move_30s": _r(f.move),
                "move_60s": _r(f.move_slow),
                "up_cents_15s": _r(f.up_cents),
                "down_cents_15s": _r(f.down_cents),
                "yes_taker_30s": f.yes_flow,
                "no_taker_30s": f.no_flow,
                "tier": stats.tier,
                "trade_rate": round(stats.trade_rate, 1),
                "profile_spread": stats.spread,
                "profile_depth": stats.depth,
                "typical_move": round(stats.typical_move, 2),
                "position": f"{position.side}:{position.remaining}" if position else "",
                "reason": self.last_reason.get(ticker, ""),
            })
        return rows

    # ------------------------------------------------------------- entries
    def _consider_entry(self, state: TickerState, now: float) -> Intent | None:
        cfg = self.cfg
        ticker = state.info.ticker

        def reject(reason: str) -> None:
            self.last_reason[ticker] = reason
            self.pending_signals.pop(ticker, None)

        if not state.book.ready:
            return reject("BOOK_NOT_READY")
        if ticker in self.blocked:
            return reject("BLOCKED_EXISTING_POSITION")
        if now < self._paused_until:
            return reject("PAUSED_ORDER_ERRORS")
        if self.daily_net_cents <= -cfg.daily_loss_limit_cents:
            return reject("DAILY_LOSS_LIMIT")
        if len(self.positions) + self._pending_buys() >= cfg.max_open_positions:
            return reject("MAX_POSITIONS")
        if now < self.cooldown_until.get(ticker, 0.0):
            return reject("COOLDOWN")
        if self.entries.get(ticker, 0) >= cfg.max_entries_per_market:
            return reject("MAX_ENTRIES_THIS_MARKET")
        if state.age(now) < cfg.min_market_age_seconds:
            return reject("MARKET_TOO_NEW")
        if state.seconds_left(now) < cfg.min_seconds_left_entry:
            return reject("TOO_CLOSE_TO_EXPIRY")

        stats = self.profiles[state.info.series].stats(now, cfg)
        if stats.tier == WARMUP:
            return reject("PROFILING_MARKET")
        rules = cfg.tiers[stats.tier]
        if not rules.tradeable:
            return reject(f"WATCH_ONLY tier={stats.tier}")

        features = compute_features(state, now, cfg)
        signal, reason = evaluate(features, stats, rules, cfg)
        if signal is None:
            return reject(reason)

        pending = self.pending_signals.get(ticker)
        if pending is None or pending.side != signal.side:
            self.pending_signals[ticker] = PendingSignal(signal.side, now, signal.ask, now, 1)
            pending = self.pending_signals[ticker]
            self._emit("signal", {"ticker": ticker, "detail": signal.detail, "tier": stats.tier})
        elif now - pending.last_ts >= cfg.signal_confirm_seconds:
            pending.streak += 1
            pending.last_ts = now

        if signal.ask - pending.first_ask > cfg.max_chase_cents:
            self.pending_signals.pop(ticker, None)
            self.last_reason[ticker] = f"CHASED ask={signal.ask}c first={pending.first_ask}c"
            return None
        if pending.streak < cfg.signal_confirmations:
            self.last_reason[ticker] = f"SIGNAL_BUILDING {pending.streak}/{cfg.signal_confirmations}"
            return None

        self.pending_signals.pop(ticker, None)
        count = cfg.size_for(stats.tier)
        limit = min(99, signal.ask + cfg.entry_slippage_cents)
        self.last_reason[ticker] = f"ENTER {signal.detail}"
        intent = Intent(
            intent_id=next(self._ids),
            ticker=ticker,
            action="buy",
            side=signal.side,
            count=count,
            limit_price=limit,
            reason="ENTRY",
            exchange_index=state.info.exchange_index,
        )
        intent_context = {
            "features": features.to_dict(),
            "profile": {
                "tier": stats.tier,
                "trade_rate": round(stats.trade_rate, 1),
                "spread": stats.spread,
                "depth": stats.depth,
                "typical_move": round(stats.typical_move, 2),
            },
            "detail": signal.detail,
        }
        self._entry_context[intent.intent_id] = intent_context
        return intent

    def _pending_buys(self) -> int:
        return sum(1 for i in self.pending_orders.values() if i.action == "buy")

    # --------------------------------------------------------------- exits
    def _manage(self, pos: Position, state: TickerState, now: float) -> Intent | None:
        cfg = self.cfg
        if pos.awaiting_settlement:
            return None
        if now >= state.info.close_ts:
            pos.awaiting_settlement = True
            self._emit("awaiting_settlement", {"ticker": pos.ticker, "remaining": pos.remaining})
            logger.warning("HELD INTO CLOSE | %s %s x%d", pos.ticker, pos.side, pos.remaining)
            return None
        if not state.book.ready:
            return None

        bid = state.book.bid(pos.side)
        if bid is not None:
            pos.peak_bid = max(pos.peak_bid, bid)
            pos.trough_bid = min(pos.trough_bid, bid)
        entry = pos.entry_price

        def sell(limit: int, reason: str) -> Intent:
            pos.last_exit_reason = reason
            return Intent(
                intent_id=next(self._ids),
                ticker=pos.ticker,
                action="sell",
                side=pos.side,
                count=pos.remaining,
                limit_price=max(1, min(99, limit)),
                reason=reason,
                exchange_index=state.info.exchange_index,
            )

        if state.seconds_left(now) <= cfg.exit_before_close_seconds:
            if bid is None:
                return None
            return sell(bid - cfg.stop_slippage_cents, "PRE_CLOSE")

        target = round(entry + cfg.take_profit_cents)
        if bid is not None and bid >= target:
            return sell(target, "TAKE_PROFIT")

        # A vanished bid counts as adverse so a dead book can't freeze the stop.
        adverse = entry - (bid if bid is not None else 0)
        if bid is not None and adverse >= cfg.hard_stop_cents:
            return sell(bid - cfg.stop_slippage_cents, "HARD_STOP")
        if adverse >= cfg.stop_loss_cents:
            if now - pos.last_stop_check >= cfg.stop_confirm_seconds:
                pos.stop_streak += 1
                pos.last_stop_check = now
            if pos.stop_streak >= cfg.stop_confirmations and bid is not None:
                return sell(bid - cfg.stop_slippage_cents, "STOP_LOSS")
            return None
        pos.stop_streak = 0

        if (
            now - pos.entry_ts >= cfg.stall_seconds
            and bid is not None
            and bid < entry + cfg.stall_min_progress_cents
        ):
            return sell(bid - cfg.stop_slippage_cents, "STALL")
        return None

    def flatten_intents(self, reason: str = "SHUTDOWN") -> list[Intent]:
        """Exit orders for every open position that can still be sold."""
        intents = []
        for ticker, pos in self.positions.items():
            state = self.markets.get(ticker)
            if pos.awaiting_settlement or ticker in self.pending_orders or state is None:
                continue
            bid = state.book.bid(pos.side) if state.book.ready else None
            if bid is None:
                continue
            pos.last_exit_reason = reason
            intent = Intent(
                intent_id=next(self._ids),
                ticker=ticker,
                action="sell",
                side=pos.side,
                count=pos.remaining,
                limit_price=max(1, bid - self.cfg.stop_slippage_cents),
                reason=reason,
                exchange_index=state.info.exchange_index,
            )
            self.pending_orders[ticker] = intent
            intents.append(intent)
        return intents

    # --------------------------------------------------------- fill events
    def on_fill(self, intent: Intent, fill: Fill, now: float) -> None:
        self.pending_orders.pop(intent.ticker, None)
        self._order_errors = 0
        context = self._entry_context.pop(intent.intent_id, None)
        state = self.markets.get(intent.ticker)

        if intent.action == "buy":
            self.entries[intent.ticker] = self.entries.get(intent.ticker, 0) + 1
            if fill.count <= 0:
                self.cooldown_until[intent.ticker] = now + 5.0
                self.last_reason[intent.ticker] = "ENTRY_NOT_FILLED"
                self._emit("entry_missed", {"ticker": intent.ticker, "limit": intent.limit_price})
                return
            ctx = context or {}
            pos = Position(
                ticker=intent.ticker,
                series=state.info.series if state else "",
                side=intent.side,
                tier=ctx.get("profile", {}).get("tier", ""),
                count=fill.count,
                entry_price=fill.avg_price,
                entry_fee=fill.fee_cents,
                entry_ts=now,
                features=ctx.get("features", {}),
                profile=ctx.get("profile", {}),
                peak_bid=0,
            )
            self.positions[intent.ticker] = pos
            logger.warning(
                "ENTRY %s | %s %s x%d @ %.1fc fee=%dc | %s",
                self.mode.upper(), intent.ticker, intent.side.upper(), fill.count,
                fill.avg_price, fill.fee_cents, ctx.get("detail", ""),
            )
            self._emit("entry", {
                "ticker": intent.ticker,
                "side": intent.side,
                "count": fill.count,
                "price": fill.avg_price,
                "fee": fill.fee_cents,
                "tier": pos.tier,
                "seconds_left": state.seconds_left(now) if state else None,
                "target": round(fill.avg_price + self.cfg.take_profit_cents),
                "stop": round(fill.avg_price - self.cfg.stop_loss_cents),
                "detail": ctx.get("detail", ""),
            })
            return

        pos = self.positions.get(intent.ticker)
        if pos is None or fill.count <= 0:
            return
        count = min(fill.count, pos.remaining)
        pos.exit_proceeds += fill.avg_price * count
        pos.exit_fees += fill.fee_cents
        pos.exited += count
        if pos.remaining <= 0:
            self._close(pos, intent.reason, now)

    def on_order_failed(self, intent: Intent, error: str, now: float) -> None:
        self.pending_orders.pop(intent.ticker, None)
        self._entry_context.pop(intent.intent_id, None)
        self._order_errors += 1
        logger.error("ORDER FAILED | %s %s %s | %s", intent.ticker, intent.action, intent.reason, error)
        self._emit("order_failed", {"ticker": intent.ticker, "action": intent.action, "error": error})
        if intent.action == "buy":
            self.cooldown_until[intent.ticker] = now + 30.0
        if self._order_errors >= self.cfg.max_order_errors:
            self._paused_until = now + self.cfg.error_pause_seconds
            logger.error("ENTRIES PAUSED %.0fs after %d order errors", self.cfg.error_pause_seconds, self._order_errors)

    def settle(self, ticker: str, result: str, now: float) -> None:
        pos = self.positions.get(ticker)
        if pos is None or result not in {"yes", "no"}:
            return
        price = 100.0 if result == pos.side else 0.0
        remaining = pos.remaining
        pos.exit_proceeds += price * remaining
        pos.exited += remaining
        self._close(pos, "SETTLEMENT_WIN" if price else "SETTLEMENT_LOSS", now)

    def _close(self, pos: Position, reason: str, now: float) -> None:
        self.positions.pop(pos.ticker, None)
        cost = pos.entry_price * pos.count
        gross = round(pos.exit_proceeds - cost)
        fees = pos.entry_fee + pos.exit_fees
        net = gross - fees
        exit_price = pos.exit_proceeds / pos.count if pos.count else 0.0

        self.stats.trades += 1
        self.stats.net_cents += net
        self.stats.fees_cents += fees
        if net > 0:
            self.stats.wins += 1
        else:
            self.stats.losses += 1
        self.daily_net_cents += net

        stopped = reason in {"STOP_LOSS", "HARD_STOP"}
        self.cooldown_until[pos.ticker] = now + (
            self.cfg.cooldown_after_stop_seconds if stopped else self.cfg.cooldown_after_exit_seconds
        )

        record = {
            "mode": self.mode,
            "series": pos.series,
            "ticker": pos.ticker,
            "tier": pos.tier,
            "side": pos.side,
            "count": pos.count,
            "entry_price": round(pos.entry_price, 2),
            "exit_price": round(exit_price, 2),
            "entry_fee": pos.entry_fee,
            "exit_fee": pos.exit_fees,
            "gross_cents": gross,
            "net_cents": net,
            "reason": reason,
            "entry_ts": datetime.fromtimestamp(pos.entry_ts, UTC).isoformat(),
            "exit_ts": datetime.fromtimestamp(now, UTC).isoformat(),
            "hold_seconds": round(now - pos.entry_ts, 1),
            "best_bid": pos.peak_bid,
            "worst_bid": pos.trough_bid if pos.trough_bid < 100 else None,
            "move_30s": pos.features.get("move"),
            "move_10s": pos.features.get("move_fast"),
            "flow_ratio": pos.features.get("flow_ratio"),
            "imbalance": pos.features.get("imbalance"),
            "spread": pos.features.get("spread"),
            "seconds_left_at_entry": _r(pos.features.get("seconds_left")),
            "trade_rate": pos.profile.get("trade_rate"),
            "typical_move": pos.profile.get("typical_move"),
            "daily_net_cents": self.daily_net_cents,
        }
        self.closed_trades.append(record)
        logger.warning(
            "EXIT %s | %s %s x%d %.1fc -> %.1fc | %s | net=%+dc (fees %dc) | day=%+dc",
            self.mode.upper(), pos.ticker, pos.side.upper(), pos.count, pos.entry_price,
            exit_price, reason, net, fees, self.daily_net_cents,
        )
        self._emit("exit", record)

    # ------------------------------------------------------------- helpers
    def _roll_day(self, now: float) -> None:
        today = datetime.fromtimestamp(now, UTC).astimezone(_CENTRAL).date()
        if today != self._day:
            self._day = today
            self.daily_net_cents = 0

    def summary(self) -> dict[str, Any]:
        s = self.stats
        return {
            "trades": s.trades,
            "wins": s.wins,
            "losses": s.losses,
            "win_rate": round(100 * s.wins / s.trades, 1) if s.trades else 0.0,
            "net_cents": s.net_cents,
            "fees_cents": s.fees_cents,
            "open_positions": len(self.positions),
        }


def _r(value: Any) -> Any:
    return None if value is None else round(float(value), 2)


__all__ = ["Features", "Fill", "Intent", "Position", "ScalperCore"]
