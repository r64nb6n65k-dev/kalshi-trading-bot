"""Backtesting framework."""
