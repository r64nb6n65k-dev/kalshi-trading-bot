"""Kalshi taker fee: ceil(rate x contracts x P x (1 - P)) in cents.

Matches the fees in the adaptive bot's trade log, e.g. 2 contracts at 75c:
0.07 x 2 x 0.75 x 0.25 = 2.6c -> 3c.
"""

from __future__ import annotations

import math


def taker_fee_cents(count: int, price_cents: int, rate: float = 0.07) -> int:
    return taker_fee_for_levels([(price_cents, count)], rate)


def taker_fee_for_levels(levels: list[tuple[int, int]], rate: float = 0.07) -> int:
    raw = sum(rate * count * price * (100 - price) / 100.0 for price, count in levels if count > 0)
    return math.ceil(raw - 1e-9) if raw > 0 else 0
