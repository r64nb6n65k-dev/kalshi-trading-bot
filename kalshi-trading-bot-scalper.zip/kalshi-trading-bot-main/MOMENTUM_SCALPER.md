# Kalshi momentum scalper

Scalps fast moves in Kalshi's 15-minute crypto and commodity markets. It reads
the live order book and trade tape and sorts each market by liquidity. It only
enters when price, real volume and the book all point the same way. Every
trade aims for +10¢ a contract after fees.

It runs in **paper mode by default** and records everything it sees, so you
can judge the strategy and retune it before risking money.

## Run it

Start command for Railway or a local run (paper mode):

```bash
python -m kalshi_bot.cli scalper
```

It needs your Kalshi API key, even for paper, because Kalshi's order-book
WebSocket is authenticated. It uses the same `KALSHI_API_KEY_ID` and
`KALSHI_PRIVATE_KEY` variables as your other bots.

Useful options:

| Option | Default | Meaning |
|---|---|---|
| `--contracts` | 5 | Size per trade in HIGH-liquidity markets (MEDIUM uses half) |
| `--take-profit` | 10 | Target in cents per contract |
| `--stop-loss` | 5 | Stop in cents per contract (a hard stop fires at 8¢ without waiting) |
| `--series` | all | Limit to series, e.g. `KXBTC15M,KXETH15M,KXSOL15M` |
| `--trade-thin` | off | Also trade THIN markets (watch-only by default) |
| `--daily-loss` | 10 | Stop new entries after this many dollars lost today (Central time) |
| `--max-positions` | 4 | Max open trades at once |

The dashboard from your other bots shows scalper trades as `scalp-paper` or
`scalp-live`.

## How it decides

**1. Liquidity tier, per series, over a rolling 10 minutes.** It measures
contracts traded per minute, the median spread, and resting depth within 3¢ of
the best price on both sides.

| Tier | Needs | Behaviour |
|---|---|---|
| HIGH | ≥300/min, depth ≥500, spread ≤2¢ | Full size, normal entry rules |
| MEDIUM | ≥50/min, depth ≥100, spread ≤3¢ | Half size, stricter rules |
| THIN | anything less | Watch only |

Each new series spends its first 2 minutes profiling before it can trade.

**2. Momentum entry.** Every condition must hold, then hold again one second
later:

- **Speed.** The 30-second move is at least 4¢ (5¢ for MEDIUM). It must also
  be at least 2× (2.5× for MEDIUM) that market's normal 30-second move, so the
  bar adjusts to how jumpy each market is.
- **Still going.** The 10-second move isn't reversing, and at least 75% of the
  last 15 seconds of price movement went the same way.
- **Not exhausted.** Price hasn't already run more than 25¢ in 60 seconds.
- **Real volume.** Taker buying in the move's direction beats the market's
  normal 30-second volume, and is at least 40% net one-sided.
- **Book agrees.** More resting size sits on the side pushing price.
- **Room to run.** Entry price is 10–85¢, the spread is tight, at least 3
  minutes are left, and the market is at least 45 seconds old.
- **No chasing.** If the ask runs more than 2¢ while the signal confirms, it
  skips the trade.

If price is rising it buys YES; if price is falling it buys NO.

**3. Exits.** All orders are immediate-or-cancel; exits are reduce-only.

- **Take profit** when the bid reaches entry +10¢.
- **Stop loss** when the bid is 5¢ under entry on two checks a second apart,
  or immediately at 8¢ under. A vanished bid counts as a loss, so a dead book
  can't freeze the stop.
- **Stall** if the trade hasn't gained 3¢ after 3 minutes.
- **Pre-close** with 60 seconds left. It never holds into settlement on
  purpose.
- **Shutdown.** On a redeploy or stop signal it tries to close open positions
  first.

**Risk controls:**

- A cooldown of 30s after an exit, or 90s after a stop.
- At most 3 entries per market window.
- The daily loss limit.
- Entries pause for 5 minutes after 3 straight order errors.
- In live mode it never touches markets where the account already holds a
  position.

## The math

Kalshi's taker fee is `ceil(7% × contracts × P × (1 − P))`, which comes to
about 2¢ a contract each way at mid prices. So, roughly:

- A win nets about **+6¢ a contract**.
- A stop costs about **−9 to −10¢**, after fees and the last tick of slippage.

The strategy needs to **win about 60% of trades** to make money. Paper results
will show whether it does.

Paper fills are **optimistic**. They fill at the displayed book the instant a
decision is made, but a real order lands 100–300ms later. Expect live entries
to be slightly worse.

## Data it records

Everything goes under `$RAILWAY_VOLUME_MOUNT_PATH/scalper/`, or `./data/scalper/`
locally. **Attach a Railway volume, or the data is lost on every redeploy.**

| File | Contents |
|---|---|
| `raw/YYYY-MM-DD.jsonl.gz` | Every order-book and trade message, used for replay |
| `ticks/YYYY-MM-DD.csv.gz` | One row per market per second: prices, depth, moves, flow, tier, and why it did or didn't trade |
| `scalper_trades.csv` | Every scalp, with entry features and P&L after fees |
| `scalper_events.csv` | Signals, entries, missed fills, order errors |
| `market_results.csv` | How every market settled |

Raw recording can grow large, since order-book updates are frequent. Check the
volume's usage after the first day. You can turn it off with `--no-raw`, but
that also disables replay.

## Tuning with your own data

```bash
# What happened: by tier, series and exit reason; liquidity per series;
# and how often a side that first hits 90c goes on to win, by time left
python -m kalshi_bot.cli scalper-report

# Re-run the recorded days with different settings, without trading
python -m kalshi_bot.cli scalper-replay --take-profit 8 --stop-loss 6
python -m kalshi_bot.cli scalper-replay --trade-thin --days 2026-10-15
```

Everything else, including tier thresholds and entry rules, lives in
`src/kalshi_bot/momentum_scalper/config.py`. The tier cutoffs are starting
guesses: check the liquidity table in `scalper-report` after a day or two and
adjust them.

## Going live

Live needs **two** switches, so it can't happen by accident:

```bash
KALSHI_SCALPER_LIVE=true python -m kalshi_bot.cli scalper --live --contracts 2
```

Suggested gate before going live:
- Run a few hundred paper trades.
- Win rate should be comfortably above 60%.
- Check that `scalper-replay` with slightly worse settings is still positive.

Start live with small size and compare live fills against paper for the same
signals.
