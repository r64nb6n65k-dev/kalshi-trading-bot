"""Re-run the scalper over recorded raw data with any settings.

Use it to tune thresholds: record a few days in paper mode, then replay the
same market data with a different take-profit, stop or liquidity rule and
compare results. Fills use the recorded book at decision time, same as paper.
"""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

from kalshi_bot.momentum_scalper.brokers import simulate_ioc
from kalshi_bot.momentum_scalper.config import ScalperConfig
from kalshi_bot.momentum_scalper.core import Fill, ScalperCore
from kalshi_bot.momentum_scalper.market_state import MarketInfo
from kalshi_bot.momentum_scalper.recorder import read_raw


def replay_records(records: Iterable[dict], cfg: ScalperConfig, step: float = 0.5) -> ScalperCore:
    core = ScalperCore(cfg, mode="replay")
    next_step: float | None = None

    def run_step(now: float) -> None:
        for intent in core.step(now):
            state = core.markets.get(intent.ticker)
            if state is None or not state.book.ready:
                core.on_fill(intent, Fill(0, 0.0, 0), now)
                continue
            core.on_fill(intent, simulate_ioc(intent, state.book, cfg.taker_fee_rate), now)
        for ticker, state in list(core.markets.items()):
            if state.info.close_ts + 5 <= now:
                core.drop_market(ticker)

    for record in records:
        rt = float(record.get("rt", 0.0))
        if next_step is None:
            next_step = rt
        if rt - next_step > 10 * step:
            next_step = rt - step
        while next_step <= rt:
            run_step(next_step)
            next_step += step

        if "market" in record:
            core.add_market(MarketInfo.from_dict(record["market"]), rt)
        elif "m" in record:
            core.on_message(record["m"], rt)
        elif "reset" in record:
            core.reset_books()
        elif "result" in record:
            result = record["result"]
            core.settle(result["ticker"], str(result["result"]).lower(), rt)
            core.drop_market(result["ticker"])
    return core


def raw_files(data_dir: Path, days: list[str] | None = None) -> list[Path]:
    folder = data_dir / "raw"
    files = sorted(folder.glob("*.jsonl.gz"))
    if days:
        wanted = set(days)
        files = [f for f in files if f.name.split(".")[0] in wanted]
    return files


def replay_files(files: list[Path], cfg: ScalperConfig, step: float = 0.5) -> ScalperCore:
    def records() -> Iterable[dict]:
        for path in files:
            yield from read_raw(path)

    return replay_records(records(), cfg, step)
