"""Synthetic Kalshi WebSocket stream for scalper tests.

Builds a 15-minute market whose YES mid follows a supplied path, publishes a
full order-book snapshot every half second and public trades with a chosen
taker mix, so tests can drive the scalper exactly as the live feed would.
"""

from __future__ import annotations

import random
from collections.abc import Callable
from typing import Any

T0 = 1_791_900_000.0  # arbitrary epoch inside a trading day


def market_record(ticker: str, series: str, open_ts: float, minutes: int = 15) -> dict[str, Any]:
    return {
        "rt": open_ts,
        "market": {
            "ticker": ticker,
            "series": series,
            "open_ts": open_ts,
            "close_ts": open_ts + minutes * 60,
            "exchange_index": None,
            "floor_strike": 100.0,
        },
    }


def snapshot(ticker: str, mid: float, depth: int, yes_tilt: float, seq: int) -> dict[str, Any]:
    bid = int(mid)  # YES bid
    ask = bid + 1 if mid == int(mid) else bid + 1
    ask = max(ask, bid + 1)
    yes_size = int(depth * (1 + yes_tilt))
    no_size = int(depth * (1 - yes_tilt))
    yes_levels = [[f"{(bid - i) / 100:.4f}", f"{yes_size:.2f}"] for i in range(5) if bid - i > 0]
    no_bid = 100 - ask
    no_levels = [[f"{(no_bid - i) / 100:.4f}", f"{no_size:.2f}"] for i in range(5) if no_bid - i > 0]
    return {
        "type": "orderbook_snapshot",
        "sid": 1,
        "seq": seq,
        "msg": {"market_ticker": ticker, "yes_dollars_fp": yes_levels, "no_dollars_fp": no_levels},
    }


def trade(ticker: str, yes_price: int, count: int, taker: str) -> dict[str, Any]:
    return {
        "type": "trade",
        "sid": 2,
        "msg": {
            "market_ticker": ticker,
            "yes_price_dollars": f"{yes_price / 100:.4f}",
            "no_price_dollars": f"{(100 - yes_price) / 100:.4f}",
            "count_fp": f"{count:.2f}",
            "taker_side": taker,
        },
    }


def build_stream(
    ticker: str,
    series: str,
    seconds: int,
    mid_at: Callable[[float], float],
    *,
    trades_at: Callable[[float], int] = lambda t: 3,
    trade_size: int = 15,
    yes_share_at: Callable[[float], float] = lambda t: 0.5,
    depth: int = 150,
    tilt_at: Callable[[float], float] = lambda t: 0.0,
    open_ts: float = T0,
    result: str | None = None,
    seed: int = 7,
) -> list[dict[str, Any]]:
    """Return raw recorder-format records (``rt`` + ``m``/``market``/``result``)."""
    rng = random.Random(seed)
    records = [market_record(ticker, series, open_ts)]
    seq = 0
    steps = int(seconds / 0.5)
    for i in range(steps + 1):
        t = i * 0.5
        rt = open_ts + t
        mid = mid_at(t)
        seq += 1
        records.append({"rt": rt, "m": snapshot(ticker, mid, depth, tilt_at(t), seq)})
        share = yes_share_at(t)
        for _ in range(trades_at(t)):
            taker = "yes" if rng.random() < share else "no"
            price = int(mid) + 1 if taker == "yes" else int(mid)
            records.append({"rt": rt + 0.01, "m": trade(ticker, price, trade_size, taker)})
    if result is not None:
        records.append({"rt": open_ts + 15 * 60 + 30, "result": {"ticker": ticker, "result": result}})
    return records


def quiet_walk(base: float = 50.0, seed: int = 3) -> Callable[[float], float]:
    """Small mean-reverting wiggle of +/-1c."""
    rng = random.Random(seed)
    cache: dict[int, float] = {}

    def mid(t: float) -> float:
        key = int(t // 10)
        if key not in cache:
            cache[key] = base + rng.choice([-1, 0, 0, 1])
        return cache[key]

    return mid
