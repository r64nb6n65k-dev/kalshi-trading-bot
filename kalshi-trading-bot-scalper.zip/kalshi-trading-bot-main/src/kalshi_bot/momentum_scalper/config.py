"""Configuration for the Kalshi momentum scalper.

Every threshold lives here so it can be tuned from recorded data (see
``scalper-replay``) without touching strategy code. The liquidity thresholds
are starting guesses: run in paper mode first, then look at the
``trade_rate``, ``depth`` and ``spread`` columns in the tick log and adjust.
"""

from __future__ import annotations

from dataclasses import dataclass, field

HIGH = "HIGH"
MEDIUM = "MEDIUM"
THIN = "THIN"
WARMUP = "WARMUP"


@dataclass(slots=True)
class TierRules:
    """Entry rules for one liquidity tier."""

    tradeable: bool
    # Minimum mid-price move (cents) over the momentum window.
    min_move_cents: float
    # The move must also be this multiple of the market's typical 30s move,
    # so a 4c move only counts in a market that normally moves 1-2c.
    vol_multiple: float
    # Directional taker volume over the flow window must reach the larger of
    # this floor and ``volume_surge`` x the market's normal volume for the
    # same window.
    min_aggressive_contracts: int
    volume_surge: float
    # (buyers - sellers) / total taker volume in the trade direction.
    min_flow_ratio: float
    # (support - resistance) / total resting depth near the top of book.
    min_book_imbalance: float
    max_spread_cents: int
    # Position size as a fraction of the configured contract count.
    size_fraction: float


def _default_tiers() -> dict[str, TierRules]:
    return {
        HIGH: TierRules(
            tradeable=True,
            min_move_cents=4,
            vol_multiple=2.0,
            min_aggressive_contracts=25,
            volume_surge=1.0,
            min_flow_ratio=0.40,
            min_book_imbalance=0.10,
            max_spread_cents=2,
            size_fraction=1.0,
        ),
        MEDIUM: TierRules(
            tradeable=True,
            min_move_cents=5,
            vol_multiple=2.5,
            min_aggressive_contracts=10,
            volume_surge=1.2,
            min_flow_ratio=0.50,
            min_book_imbalance=0.20,
            max_spread_cents=3,
            size_fraction=0.5,
        ),
        THIN: TierRules(
            # Watch-only by default: in thin books a "move" is often a quote
            # jumping, and the exit may not fill.
            tradeable=False,
            min_move_cents=6,
            vol_multiple=3.0,
            min_aggressive_contracts=5,
            volume_surge=1.5,
            min_flow_ratio=0.60,
            min_book_imbalance=0.30,
            max_spread_cents=3,
            size_fraction=0.4,
        ),
    }


@dataclass(slots=True)
class ScalperConfig:
    # ---- sizing / exits --------------------------------------------------
    contracts: int = 5
    take_profit_cents: int = 10
    stop_loss_cents: int = 5
    # Beyond this adverse move, exit immediately without waiting for a
    # second confirmation.
    hard_stop_cents: int = 8
    stop_confirmations: int = 2
    stop_confirm_seconds: float = 1.0
    # Exit if the trade hasn't made this much progress after this long.
    stall_seconds: float = 180.0
    stall_min_progress_cents: int = 3
    # Never hold into the last minute: settlement flips are where scalps die.
    exit_before_close_seconds: float = 60.0

    # ---- entry filters ---------------------------------------------------
    min_seconds_left_entry: float = 180.0
    min_market_age_seconds: float = 45.0
    min_entry_price: int = 10
    max_entry_price: int = 85
    # Skip if price already ran this far in the last 60s (late chase).
    max_run_cents: float = 25.0
    # Share of the recent price path (in cents) that went in the trade
    # direction, measured over ``consistency_window`` seconds.
    consistency_min: float = 0.75
    consistency_window: float = 15.0
    signal_confirmations: int = 2
    signal_confirm_seconds: float = 1.0
    # Abandon a building signal if the ask runs this far past where it began.
    max_chase_cents: int = 2

    # ---- execution -------------------------------------------------------
    entry_slippage_cents: int = 1
    stop_slippage_cents: int = 3
    taker_fee_rate: float = 0.07

    # ---- feature windows (seconds) ---------------------------------------
    fast_window: float = 10.0
    move_window: float = 30.0
    slow_window: float = 60.0
    flow_window: float = 30.0
    depth_band_cents: int = 3

    # ---- risk ------------------------------------------------------------
    cooldown_after_exit_seconds: float = 30.0
    cooldown_after_stop_seconds: float = 90.0
    max_entries_per_market: int = 3
    max_open_positions: int = 4
    daily_loss_limit_cents: int = 1_000
    # Consecutive live order errors before entries pause.
    max_order_errors: int = 3
    error_pause_seconds: float = 300.0

    # ---- liquidity profiling (per series, rolling) -----------------------
    profile_window_seconds: float = 600.0
    profile_warmup_seconds: float = 120.0
    high_min_trade_rate: float = 300.0  # contracts per minute
    high_min_depth: float = 500.0  # contracts within depth band, both sides
    high_max_spread: float = 2.0
    medium_min_trade_rate: float = 50.0
    medium_min_depth: float = 100.0
    medium_max_spread: float = 3.0

    tiers: dict[str, TierRules] = field(default_factory=_default_tiers)

    def size_for(self, tier: str) -> int:
        rules = self.tiers.get(tier)
        if rules is None:
            return 0
        return max(1, round(self.contracts * rules.size_fraction))
