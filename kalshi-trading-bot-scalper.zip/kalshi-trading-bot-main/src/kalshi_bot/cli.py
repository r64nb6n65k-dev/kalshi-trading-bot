"""Command-line interface for the Kalshi Trading Bot.

Run ``kalshi-bot --help`` after installing, or ``python -m kalshi_bot --help``.

Includes CobyStrategy and the Coby dashboard.
"""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console
from rich.table import Table

from kalshi_bot import __version__
from kalshi_bot.backtesting.data import random_walk_snapshots
from kalshi_bot.backtesting.engine import Backtester
from kalshi_bot.backtesting.report import render as render_report
from kalshi_bot.config import load_settings
from kalshi_bot.core.all_15m_engine import All15mEngine
from kalshi_bot.core.engine import TradingEngine
from kalshi_bot.core.polymarket_live_engine import PolymarketLiveEngine, PolymarketTradingClient
from kalshi_bot.core.polymarket_sim_engine import PolymarketSimEngine
from kalshi_bot.dashboard import start_dashboard
from kalshi_bot.data.chainlink_twap import ChainlinkTwapFeed
from kalshi_bot.data.gold import GoldPriceFeed
from kalshi_bot.data.multi_asset import MultiAssetPriceFeed
from kalshi_bot.data.multi_crypto import MultiCryptoPriceFeed
from kalshi_bot.exchange.client import KalshiClient
from kalshi_bot.polymarket import PolymarketPublicClient
from kalshi_bot.portfolio.ladder_engine import SameDayLadderEngine
from kalshi_bot.risk.manager import RiskManager
from kalshi_bot.scalping.engine import BtcOrderBookScalpingEngine
from kalshi_bot.strategies.base import Strategy
from kalshi_bot.strategies.examples.all_15m_momentum import All15mMomentumStrategy
from kalshi_bot.strategies.examples.arbitrage import ArbitrageYesNo
from kalshi_bot.strategies.examples.coby_strategy import CobyStrategy
from kalshi_bot.strategies.examples.fair_value import FairValue
from kalshi_bot.strategies.examples.market_maker import MarketMaker
from kalshi_bot.strategies.examples.mean_reversion import MeanReversion
from kalshi_bot.strategies.examples.momentum import Momentum
from kalshi_bot.strategies.examples.polymarket_momentum import PolymarketMomentumStrategy

app = typer.Typer(
    add_completion=False,
    help="Kalshi Trading Bot â open-source framework by Viprasol Tech.",
)
console = Console()


STRATEGIES: dict[str, type[Strategy]] = {
    "market_maker": MarketMaker,
    "momentum": Momentum,
    "mean_reversion": MeanReversion,
    "arbitrage": ArbitrageYesNo,
    "fair_value": FairValue,
    "coby_strategy": CobyStrategy,
}


@app.command()
def version() -> None:
    """Print the installed version."""
    console.print(f"kalshi-trading-bot [bold cyan]{__version__}[/] â by Viprasol Tech")


@app.command()
def strategies() -> None:
    """List registered strategies."""
    table = Table(title="Registered strategies")
    table.add_column("Name", style="cyan")
    table.add_column("Class")
    table.add_column("Summary")

    summaries = {
        "market_maker": "Quote both sides around mid with an inventory cap.",
        "momentum": "Trade in the direction of short-term last-price momentum.",
        "mean_reversion": "Fade moves beyond N standard deviations from the mean.",
        "arbitrage": "Buy YES+NO when their combined ask is below 100c.",
        "fair_value": "Buy YES below your fair probability, Kelly-sized.",
        "coby_strategy": "Coby's 15-minute gold strategy.",
    }

    for name, cls in STRATEGIES.items():
        table.add_row(name, cls.__name__, summaries.get(name, ""))

    console.print(table)


@app.command()
def backtest(
    strategy: str = typer.Argument(
        "momentum",
        help=f"One of: {', '.join(STRATEGIES)}",
    ),
    ticks: int = typer.Option(
        200,
        help="Number of synthetic snapshots to replay.",
    ),
    balance: int = typer.Option(
        100_000,
        help="Starting balance in cents.",
    ),
    seed: int = typer.Option(
        42,
        help="RNG seed for the synthetic random walk.",
    ),
) -> None:
    """Backtest a strategy on synthetic data and print a metrics report."""
    if strategy not in STRATEGIES:
        choices = ", ".join(STRATEGIES)
        console.print(f"[red]Unknown strategy '{strategy}'. Choose from: {choices}[/]")
        raise typer.Exit(code=1)

    snapshots = random_walk_snapshots(n=ticks, seed=seed)
    bt = Backtester(starting_balance_cents=balance)
    report = bt.run(STRATEGIES[strategy](), snapshots)
    render_report(
        report,
        console=console,
        title=f"Backtest: {strategy} ({ticks} ticks)",
    )


@app.command()
def markets(
    status: str = typer.Option(
        "open",
        help="Filter by market status.",
    ),
    limit: int = typer.Option(
        10,
        help="Maximum markets to list.",
    ),
) -> None:
    """List markets from Kalshi."""

    async def _run() -> None:
        settings = load_settings()

        async with KalshiClient.from_settings(settings) as client:
            rows = await client.get_markets(
                status=status,
                limit=limit,
            )

            table = Table(title=f"Kalshi markets ({settings.environment.value})")
            table.add_column("Ticker", style="cyan")
            table.add_column("Title")
            table.add_column("Yes Bid", justify="right")
            table.add_column("Yes Ask", justify="right")

            for m in rows:
                table.add_row(
                    m.ticker,
                    m.title or "-",
                    str(m.yes_bid),
                    str(m.yes_ask),
                )

            console.print(table)

    asyncio.run(_run())


@app.command()
def balance() -> None:
    """Show portfolio balance."""

    async def _run() -> None:
        settings = load_settings()

        async with KalshiClient.from_settings(settings) as client:
            if not client.authenticated:
                console.print("[red]No credentials configured. Set KALSHI_API_KEY_ID.[/]")
                raise typer.Exit(code=1)

            bal = await client.get_balance()

            console.print(f"Balance: [bold green]${bal.balance / 100:,.2f}[/]")

    asyncio.run(_run())


@app.command()
def run(
    strategy: str = typer.Argument(
        ...,
        help=f"One of: {', '.join(STRATEGIES)}",
    ),
    ticker: str = typer.Argument(
        ...,
        help="Market ticker or series ticker to trade.",
    ),
    ticks: int = typer.Option(
        0,
        help="Number of poll cycles before stopping (0 runs continuously).",
    ),
    live: bool = typer.Option(
        False,
        "--live",
        help="Send real orders (default is dry-run).",
    ),
) -> None:
    """Run a strategy live or in dry-run mode."""
    if strategy not in STRATEGIES:
        choices = ", ".join(STRATEGIES)
        console.print(f"[red]Unknown strategy '{strategy}'. Choose from: {choices}[/]")
        raise typer.Exit(code=1)

    # Keep the web dashboard running in the same Railway process.
    start_dashboard()

    async def _run() -> None:
        settings = load_settings()

        # Dry-run unless --live is explicitly passed.
        dry_run = not live

        async with KalshiClient.from_settings(settings) as client:
            underlying_feed = None
            strategy_params = {}
            if strategy == "coby_strategy":
                underlying_feed = GoldPriceFeed(
                    base_url="",
                    price_feed_id="XAU_USD",
                    api_key=settings.pyth_api_key,
                )
                strategy_params["max_underlying_age_seconds"] = settings.gold_max_age_seconds
            engine = TradingEngine(
                client=client,
                strategy=STRATEGIES[strategy](**strategy_params),
                risk=RiskManager.from_settings(settings.risk),
                dry_run=dry_run,
                poll_interval=settings.poll_interval,
                underlying_feed=underlying_feed,
            )

            await engine.run(
                ticker,
                max_ticks=None if ticks == 0 else ticks,
            )

    asyncio.run(_run())


@app.command("btc-scalper")
def btc_scalper(
    events: int = typer.Option(
        0,
        help="Order-book deltas to record before stopping (0 runs continuously).",
    ),
    live: bool = typer.Option(
        False,
        "--live",
        help="Reserved for the validated live build; currently safety-locked.",
    ),
) -> None:
    """Record and queue-simulate the KXBTC15M order book."""

    async def _run() -> None:
        settings = load_settings()
        if live:
            console.print(
                "[red]Live maker trading is safety-locked until dry-run queue validation passes.[/]"
            )
            raise typer.Exit(code=2)
        async with KalshiClient.from_settings(settings) as client:
            from kalshi_bot.exchange.websocket import KalshiWebSocket

            websocket = KalshiWebSocket.from_settings(settings)
            engine = BtcOrderBookScalpingEngine(
                client=client,
                websocket=websocket,
                dry_run=True,
            )
            await engine.run(max_events=None if events == 0 else events)

    asyncio.run(_run())


@app.command("same-day-ladders")
def same_day_ladders(
    cycles: int = typer.Option(
        0,
        help="All-market scans before stopping (0 runs continuously).",
    ),
    bankroll: int = typer.Option(500, min=100, help="Paper bankroll in dollars."),
    contracts: int = typer.Option(5, min=1, max=50, help="Maximum pairs per opportunity."),
    minimum_edge: int = typer.Option(
        3,
        min=1,
        max=25,
        help="Minimum profit in cents per pair after estimated fees.",
    ),
    live: bool = typer.Option(
        False,
        "--live",
        help="Reserved until paired-fill telemetry validates execution.",
    ),
) -> None:
    """Scan every category for depth-confirmed ladders closing today Central."""
    if live:
        console.print(
            "[red]same-day-ladders is paper-only until partial-fill risk is validated.[/]"
        )
        raise typer.Exit(code=2)
    start_dashboard()

    async def _run() -> None:
        settings = load_settings()
        async with KalshiClient.from_settings(settings) as client:
            engine = SameDayLadderEngine(
                client=client,
                bankroll_cents=bankroll * 100,
                poll_interval=max(5.0, settings.poll_interval),
                contracts_per_pair=contracts,
                minimum_profit_per_pair=minimum_edge,
            )
            await engine.run(max_cycles=None if cycles == 0 else cycles)

    asyncio.run(_run())


@app.command("all-15m")
def all_15m(
    cycles: int = typer.Option(0, help="Scan cycles before stopping (0 runs continuously)."),
    bankroll: int = typer.Option(500, min=1, help="Maximum strategy bankroll in dollars."),
    contracts: int = typer.Option(10, min=1, help="Contracts per trade."),
    live: bool = typer.Option(False, "--live", help="Send real orders (default is paper)."),
) -> None:
    """Monitor and directionally trade every supported 15-minute commodity market."""
    start_dashboard()

    async def _run() -> None:
        settings = load_settings()
        async with KalshiClient.from_settings(settings) as client:
            if live and not client.authenticated:
                console.print("[red]Live mode requires Kalshi credentials.[/]")
                raise typer.Exit(code=1)
            engine = All15mEngine(
                client=client,
                strategy=All15mMomentumStrategy(
                    bankroll_cents=bankroll * 100,
                    contracts=contracts,
                ),
                risk=RiskManager.from_settings(settings.risk),
                dry_run=not live,
                poll_interval=settings.poll_interval,
                price_feed=MultiAssetPriceFeed(settings),
            )
            await engine.run(max_cycles=None if cycles == 0 else cycles)

    asyncio.run(_run())


@app.command("polymarket-sim")
def polymarket_sim(
    cycles: int = typer.Option(0, help="Scan cycles before stopping (0 runs continuously)."),
    bankroll: int = typer.Option(500, min=1, help="Paper bankroll in dollars."),
    contracts: int = typer.Option(10, min=1, help="Paper contracts per trade."),
    intervals: str = typer.Option("5", help="Rolling market lengths: 5, 15, or 5,15."),
    poll: float = typer.Option(1.0, min=0.25, help="Quote polling interval in seconds."),
) -> None:
    """Simulate the live crypto strategy on Polymarket 5m and 15m markets."""
    try:
        parsed_intervals = tuple(int(value.strip()) for value in intervals.split(","))
    except ValueError as exc:
        raise typer.BadParameter("intervals must be 5, 15, or 5,15") from exc
    if not parsed_intervals or set(parsed_intervals) - {5, 15}:
        raise typer.BadParameter("intervals must be 5, 15, or 5,15")

    start_dashboard()

    async def _run() -> None:
        settings = load_settings()
        async with PolymarketPublicClient(intervals=parsed_intervals) as client:
            feed = MultiCryptoPriceFeed(
                settings.btc_ws_url,
                tuple(client.ASSETS.values()),
            )
            engine = PolymarketSimEngine(
                client=client,
                feed=feed,
                reference_feed=ChainlinkTwapFeed(tuple(client.ASSETS.values())),
                strategy=PolymarketMomentumStrategy(
                    bankroll_cents=bankroll * 100,
                    contracts=contracts,
                ),
                poll_interval=poll,
            )
            await engine.run(max_cycles=None if cycles == 0 else cycles)

    asyncio.run(_run())


@app.command("polymarket-auth-check")
def polymarket_auth_check() -> None:
    """Validate Polymarket signer/wallet auth and Railway geolocation without trading."""

    async def _run() -> None:
        client = PolymarketTradingClient()
        geo = await client.check_geoblock()
        balance = await client.collateral_balance()
        if geo.get("blocked"):
            console.print(
                "[red]BLOCKED[/] Railway server location: "
                f"{geo.get('country')} / {geo.get('region')}"
            )
            raise typer.Exit(code=2)
        masked = f"{client.wallet[:6]}...{client.wallet[-4:]}"
        console.print(f"[green]Polymarket auth OK[/] | wallet={masked}")
        console.print(
            f"Railway server location: {geo.get('country')} / {geo.get('region')} (eligible)"
        )
        if balance is not None:
            console.print(f"Reported collateral balance: ${balance:.2f}")

    asyncio.run(_run())


@app.command("polymarket-live")
def polymarket_live(
    cycles: int = typer.Option(0, help="Scan cycles before stopping (0 runs continuously)."),
    bankroll: int = typer.Option(30, min=1, help="Hard strategy bankroll cap in dollars."),
    contracts: int = typer.Option(2, min=1, help="Contracts per trade."),
    intervals: str = typer.Option("5", help="Rolling market lengths: 5, 15, or 5,15."),
    poll: float = typer.Option(1.0, min=0.25, help="Quote polling interval in seconds."),
    live: bool = typer.Option(
        False, "--live", help="Enable real CLOB orders; also requires POLY_LIVE=true."
    ),
) -> None:
    """Run the Polymarket momentum strategy with confirmed real CLOB execution."""
    try:
        parsed_intervals = tuple(int(value.strip()) for value in intervals.split(","))
    except ValueError as exc:
        raise typer.BadParameter("intervals must be 5, 15, or 5,15") from exc
    if not parsed_intervals or set(parsed_intervals) - {5, 15}:
        raise typer.BadParameter("intervals must be 5, 15, or 5,15")

    start_dashboard()

    async def _run() -> None:
        settings = load_settings()
        async with PolymarketPublicClient(
            intervals=parsed_intervals, international_only=True
        ) as market_client:
            feed = MultiCryptoPriceFeed(
                settings.btc_ws_url,
                tuple(market_client.ASSETS.values()),
            )
            engine = PolymarketLiveEngine(
                market_client=market_client,
                trading_client=PolymarketTradingClient(),
                feed=feed,
                reference_feed=ChainlinkTwapFeed(tuple(market_client.ASSETS.values())),
                strategy=PolymarketMomentumStrategy(
                    bankroll_cents=bankroll * 100,
                    contracts=contracts,
                ),
                poll_interval=poll,
                live_enabled=live,
            )
            await engine.run(max_cycles=None if cycles == 0 else cycles)

    asyncio.run(_run())


# --------------------------------------------------------------------------
# Momentum scalper
# --------------------------------------------------------------------------


def _scalper_config(
    contracts: int,
    take_profit: int,
    stop_loss: int,
    trade_thin: bool,
    daily_loss: float,
    max_positions: int,
):
    from kalshi_bot.momentum_scalper.config import THIN, ScalperConfig

    cfg = ScalperConfig(
        contracts=contracts,
        take_profit_cents=take_profit,
        stop_loss_cents=stop_loss,
        hard_stop_cents=max(stop_loss + 3, 8),
        daily_loss_limit_cents=int(daily_loss * 100),
        max_open_positions=max_positions,
    )
    cfg.max_entry_price = min(cfg.max_entry_price, 97 - take_profit)
    if trade_thin:
        cfg.tiers[THIN].tradeable = True
    return cfg


def _print_rows(title: str, rows: list[dict]) -> None:
    if not rows:
        console.print(f"[dim]{title}: no data yet[/]")
        return
    table = Table(title=title)
    for key in rows[0]:
        table.add_column(str(key))
    for row in rows:
        table.add_row(*(str(v) for v in row.values()))
    console.print(table)


@app.command("scalper")
def scalper(
    minutes: float = typer.Option(0, help="Minutes to run (0 runs continuously)."),
    contracts: int = typer.Option(5, min=1, max=100, help="Contracts per trade (HIGH tier; MEDIUM uses half)."),
    take_profit: int = typer.Option(10, min=2, max=40, help="Take-profit in cents per contract."),
    stop_loss: int = typer.Option(5, min=1, max=40, help="Stop-loss in cents per contract."),
    series: str = typer.Option("", help="Comma-separated series to trade, e.g. KXBTC15M,KXETH15M. Empty = all 15m crypto + commodities."),
    categories: str = typer.Option("Crypto,Commodities", help="Kalshi categories scanned for 15m series."),
    trade_thin: bool = typer.Option(False, help="Also trade THIN-liquidity markets (watch-only by default)."),
    daily_loss: float = typer.Option(10.0, min=1.0, help="Stop new entries after this daily loss, in dollars."),
    max_positions: int = typer.Option(4, min=1, max=20, help="Max simultaneous positions."),
    data_dir: str = typer.Option("", help="Where to record data (default: Railway volume or ./data/scalper)."),
    no_raw: bool = typer.Option(False, help="Skip raw WebSocket recording (disables replay)."),
    live: bool = typer.Option(False, "--live", help="Send real orders. Also requires KALSHI_SCALPER_LIVE=true."),
) -> None:
    """Momentum scalper for Kalshi 15-minute markets (paper by default)."""
    import os

    from kalshi_bot.exchange.websocket import KalshiWebSocket
    from kalshi_bot.momentum_scalper.brokers import LiveBroker, PaperBroker
    from kalshi_bot.momentum_scalper.core import ScalperCore
    from kalshi_bot.momentum_scalper.recorder import Recorder
    from kalshi_bot.momentum_scalper.runner import ScalperRunner
    from kalshi_bot.telemetry.logging import configure_logging

    configure_logging()
    if live and os.getenv("KALSHI_SCALPER_LIVE", "").lower() != "true":
        console.print("[red]--live also requires KALSHI_SCALPER_LIVE=true in the environment.[/]")
        raise typer.Exit(code=2)

    cfg = _scalper_config(contracts, take_profit, stop_loss, trade_thin, daily_loss, max_positions)
    start_dashboard()

    async def _run() -> None:
        settings = load_settings()
        async with KalshiClient.from_settings(settings) as client:
            if not client.authenticated:
                console.print("[red]Kalshi API credentials are required (the order-book WebSocket is authenticated).[/]")
                raise typer.Exit(code=1)
            if live:
                bal = await client.get_balance()
                console.print(f"[yellow]LIVE scalper[/] | balance ${bal.balance / 100:,.2f}")
            core = ScalperCore(cfg, mode="live" if live else "paper")
            broker = LiveBroker(client, cfg.taker_fee_rate) if live else PaperBroker(cfg.taker_fee_rate)
            runner = ScalperRunner(
                client=client,
                websocket=KalshiWebSocket.from_settings(settings),
                core=core,
                broker=broker,
                recorder=Recorder(data_dir or None, record_raw=not no_raw),
                categories=tuple(c.strip() for c in categories.split(",") if c.strip()),
                series=tuple(s.strip() for s in series.split(",") if s.strip()),
            )
            await runner.run(max_seconds=minutes * 60 if minutes else None)

    asyncio.run(_run())


@app.command("scalper-replay")
def scalper_replay(
    data_dir: str = typer.Option("", help="Recorded data directory."),
    days: str = typer.Option("", help="Comma-separated UTC days (YYYY-MM-DD). Empty = all."),
    contracts: int = typer.Option(5, min=1),
    take_profit: int = typer.Option(10, min=2, max=40),
    stop_loss: int = typer.Option(5, min=1, max=40),
    trade_thin: bool = typer.Option(False),
    daily_loss: float = typer.Option(10.0, min=1.0),
    max_positions: int = typer.Option(4, min=1),
) -> None:
    """Re-run the scalper over recorded market data with different settings."""
    from collections import defaultdict
    from pathlib import Path

    from kalshi_bot.momentum_scalper.recorder import default_data_dir
    from kalshi_bot.momentum_scalper.replay import raw_files, replay_files

    folder = Path(data_dir) if data_dir else default_data_dir()
    files = raw_files(folder, [d.strip() for d in days.split(",") if d.strip()] or None)
    if not files:
        console.print(f"[red]No raw recordings in {folder / 'raw'}[/]")
        raise typer.Exit(code=1)
    cfg = _scalper_config(contracts, take_profit, stop_loss, trade_thin, daily_loss, max_positions)
    core = replay_files(files, cfg)
    _print_rows("Replay summary", [core.summary()])
    for key in ("tier", "series", "reason"):
        groups: dict[str, list[int]] = defaultdict(list)
        for trade in core.closed_trades:
            groups[str(trade[key])].append(int(trade["net_cents"]))
        _print_rows(f"By {key}", [
            {key: k, "trades": len(v), "win_rate": round(100 * sum(n > 0 for n in v) / len(v), 1),
             "net_$": round(sum(v) / 100, 2)}
            for k, v in sorted(groups.items())
        ])


@app.command("scalper-report")
def scalper_report(
    data_dir: str = typer.Option("", help="Recorded data directory."),
    level: int = typer.Option(90, min=51, max=99, help="Price level for the hold-rate table."),
) -> None:
    """Summarise recorded scalper trades, market liquidity and hold rates."""
    from pathlib import Path

    from kalshi_bot.momentum_scalper.recorder import default_data_dir
    from kalshi_bot.momentum_scalper.report import hold_rate_at, liquidity_summary, trade_summary

    folder = Path(data_dir) if data_dir else default_data_dir()
    for key, rows in trade_summary(folder).items():
        _print_rows(f"Scalps by {key}", rows)
    _print_rows("Market liquidity (medians)", liquidity_summary(folder))
    _print_rows(f"Hold rate after first touch of {level}c", hold_rate_at(folder, level))


if __name__ == "__main__":
    app()
